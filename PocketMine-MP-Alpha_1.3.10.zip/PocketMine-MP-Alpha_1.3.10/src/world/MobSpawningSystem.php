<?php

/**
 * Vanilla Mob Spawning System for PocketMine-MP Alpha 1.3.10
 * 
 * Implements dynamic mob spawning that mimics vanilla Minecraft behavior:
 * - Time-based spawning (hostile at night, passive during day)
 * - Location-based spawning around players
 * - Configurable spawn rates and limits
 * - Proper mob distribution
 * 
 * @author AxoGM
 */

class MobSpawningSystem {
    private $server;
    private $spawnedMobs = array();
    private $lastSpawnAttempt = 0;
    private $mobAI = null;
    
    // Configuration constants
    const SPAWN_INTERVAL = 600; // 30 seconds in ticks (20 ticks per second)
    const MIN_SPAWN_RADIUS = 8; // Minimum distance from player
    const MAX_SPAWN_RADIUS = 32; // Maximum distance from player
    const MAX_MOBS_PER_PLAYER = 6; // Maximum mobs around each player
    const MAX_TOTAL_MOBS = 30; // Maximum total mobs on server
    
    // Mob spawn weights (higher = more likely to spawn)
    private $hostileMobWeights = array(
        MOB_ZOMBIE => 100,
        MOB_SKELETON => 80,
        MOB_CREEPER => 60,
        MOB_SPIDER => 70
    );
    
    private $passiveMobWeights = array(
        MOB_PIG => 100,
        MOB_COW => 80,
        MOB_SHEEP => 90,
        MOB_CHICKEN => 70
    );
    
    public function __construct($mobAI = null) {
        $this->server = ServerAPI::request();
        $this->mobAI = $mobAI;
        $this->initializeSpawning();
    }
    
    /**
     * Set the MobAI reference
     */
    public function setMobAI($mobAI) {
        $this->mobAI = $mobAI;
    }
    
    private function initializeSpawning() {
        // Schedule mob spawning
        $this->server->schedule(self::SPAWN_INTERVAL, array($this, "attemptMobSpawning"), array(), true);
        
        // Schedule mob cleanup (remove mobs that are too far from players)
        $this->server->schedule(20 * 30, array($this, "cleanupDistantMobs"), array(), true); // Every 30 seconds
        
        // Register event handlers
        $this->server->addHandler("entity.death", array($this, "handleMobDeath"), 1);
        
        console("[MOB-SPAWN] Mob spawning system initialized");
    }
    
    /**
     * Main mob spawning logic - called every spawn interval
     */
    public function attemptMobSpawning() {
        $totalMobs = count($this->spawnedMobs);
        
        if ($totalMobs >= self::MAX_TOTAL_MOBS) {
            return; // Too many mobs already
        }
        
        $players = $this->server->api->player->getAll();
        if (empty($players)) {
            return; // No players online
        }
        
        foreach ($players as $player) {
            if (!($player instanceof Player) || !($player->entity instanceof Entity)) {
                continue;
            }
            
            $this->attemptSpawnAroundPlayer($player);
        }
        
        console("[MOB-SPAWN] Spawn cycle completed. Total mobs: " . count($this->spawnedMobs));
    }
    
    /**
     * Attempt to spawn mobs around a specific player
     */
    private function attemptSpawnAroundPlayer($player) {
        $level = $player->level;
        $playerPos = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y,
            'z' => $player->entity->z
        );
        
        // Count existing mobs around this player
        $nearbyMobs = $this->countMobsAroundPlayer($player);
        if ($nearbyMobs >= self::MAX_MOBS_PER_PLAYER) {
            return; // Too many mobs around this player
        }
        
        // Determine what type of mobs to spawn based on time
        $isNight = $this->isNightTime($level);
        $mobTypes = $isNight ? $this->hostileMobWeights : $this->passiveMobWeights;
        
        // Attempt to spawn 1-3 mobs
        $spawnAttempts = mt_rand(1, 3);
        
        for ($i = 0; $i < $spawnAttempts; $i++) {
            if (count($this->spawnedMobs) >= self::MAX_TOTAL_MOBS) {
                break;
            }
            
            $spawnPos = $this->findValidSpawnLocation($playerPos, $level);
            if ($spawnPos === null) {
                continue; // Couldn't find valid spawn location
            }
            
            $mobType = $this->selectMobType($mobTypes);
            if ($mobType === null) {
                continue;
            }
            
            $this->spawnMob($mobType, $spawnPos, $level);
        }
    }
    
    /**
     * Check if it's night time in the level
     */
    private function isNightTime($level) {
        $time = $level->getTime();
        // Night time is roughly from 13000 to 23000 in Minecraft time
        return $time >= 13000 && $time <= 23000;
    }
    
    /**
     * Count mobs around a player
     */
    private function countMobsAroundPlayer($player) {
        $count = 0;
        $playerPos = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y,
            'z' => $player->entity->z
        );
        
        foreach ($this->spawnedMobs as $mobEID => $mobData) {
            $mob = $this->server->api->entity->get($mobEID);
            if (!($mob instanceof Entity) || $mob->level !== $player->level) {
                continue;
            }
            
            $distance = $this->calculateDistance($playerPos, array(
                'x' => $mob->x,
                'y' => $mob->y,
                'z' => $mob->z
            ));
            
            if ($distance <= self::MAX_SPAWN_RADIUS) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Find a valid spawn location around the player
     */
    private function findValidSpawnLocation($playerPos, $level) {
        $attempts = 0;
        $maxAttempts = 20;
        
        while ($attempts < $maxAttempts) {
            // Generate random position within spawn radius
            $angle = mt_rand(0, 360) * (M_PI / 180);
            $distance = mt_rand(self::MIN_SPAWN_RADIUS, self::MAX_SPAWN_RADIUS);
            
            $x = $playerPos['x'] + cos($angle) * $distance;
            $z = $playerPos['z'] + sin($angle) * $distance;
            
            // Find suitable Y coordinate (ground level)
            $y = $this->findGroundLevel($x, $z, $level);
            if ($y === null) {
                $attempts++;
                continue;
            }
            
            $spawnPos = array('x' => $x, 'y' => $y + 1, 'z' => $z);
            
            // Validate spawn location
            if ($this->isValidSpawnLocation($spawnPos, $level)) {
                return $spawnPos;
            }
            
            $attempts++;
        }
        
        return null; // Couldn't find valid location
    }
    
    /**
     * Find ground level at given X, Z coordinates
     */
    private function findGroundLevel($x, $z, $level) {
        $blockX = floor($x);
        $blockZ = floor($z);
        
        // Search from top to bottom for solid ground
        for ($y = 127; $y >= 1; $y--) {
            $blockData = $level->level->getBlock($blockX, $y, $blockZ);
            $blockId = $blockData[0];
            $blockAboveData = $level->level->getBlock($blockX, $y + 1, $blockZ);
            $blockAbove = $blockAboveData[0];
            
            // Found solid block with air above
            if ($this->isSolidBlock($blockId) && $blockAbove === AIR) {
                return $y;
            }
        }
        
        return null; // No suitable ground found
    }
    
    /**
     * Check if a block is solid (suitable for mob spawning on top)
     */
    private function isSolidBlock($blockId) {
        $solidBlocks = array(
            GRASS, DIRT, STONE, COBBLESTONE, SAND, GRAVEL,
            WOOD, PLANKS, LEAVES, SANDSTONE, CLAY_BLOCK
        );
        
        return in_array($blockId, $solidBlocks);
    }
    
    /**
     * Validate if a position is suitable for mob spawning
     */
    private function isValidSpawnLocation($pos, $level) {
        $x = floor($pos['x']);
        $y = floor($pos['y']);
        $z = floor($pos['z']);
        
        // Check if spawn location has enough space (2 blocks high)
        $block1Data = $level->level->getBlock($x, $y, $z);
        $block1 = $block1Data[0];
        $block2Data = $level->level->getBlock($x, $y + 1, $z);
        $block2 = $block2Data[0];
        
        if ($block1 !== AIR || $block2 !== AIR) {
            return false; // Not enough space
        }
        
        // Check if there's solid ground below
        $blockBelowData = $level->level->getBlock($x, $y - 1, $z);
        $blockBelow = $blockBelowData[0];
        if (!$this->isSolidBlock($blockBelow)) {
            return false; // No solid ground
        }
        
        // Skip light level check for now as it's not available in Alpha 1.3.10
        // In a more advanced version, you would check light levels here
        
        return true;
    }
    
    /**
     * Select mob type based on weights
     */
    private function selectMobType($mobWeights) {
        if (empty($mobWeights)) {
            return null;
        }
        
        $totalWeight = array_sum($mobWeights);
        $random = mt_rand(1, $totalWeight);
        
        $currentWeight = 0;
        foreach ($mobWeights as $mobType => $weight) {
            $currentWeight += $weight;
            if ($random <= $currentWeight) {
                return $mobType;
            }
        }
        
        // Fallback to first mob type
        return array_keys($mobWeights)[0];
    }
    
    /**
     * Spawn a mob at the specified location
     */
    private function spawnMob($mobType, $pos, $level) {
        // Create mob entity
        $mob = $this->server->api->entity->add($level, ENTITY_MOB, $mobType, array(
            "x" => $pos['x'],
            "y" => $pos['y'],
            "z" => $pos['z'],
            "yaw" => mt_rand(0, 360),
            "pitch" => 0
        ));
        
        if ($mob instanceof Entity) {
            // Track spawned mob
            $this->spawnedMobs[$mob->eid] = array(
                'type' => $mobType,
                'spawnTime' => time(),
                'level' => $level->getName()
            );
            
            // Ensure mob is spawned to all players
            $this->server->api->entity->spawnToAll($mob);
            
            // Set mob health and properties
            $mob->setHealth($this->getMobMaxHealth($mobType));
            
            // Initialize AI for this mob manually since entity.spawn event might not trigger
            $this->initializeMobAI($mob);
            
            $mobName = $this->getMobName($mobType);
            console("[MOB-SPAWN] Spawned " . $mobName . " at (" . round($pos['x'], 1) . ", " . round($pos['y'], 1) . ", " . round($pos['z'], 1) . ") - EID: " . $mob->eid);
        } else {
            console("[MOB-SPAWN] Failed to spawn " . $this->getMobName($mobType) . " at (" . round($pos['x'], 1) . ", " . round($pos['y'], 1) . ", " . round($pos['z'], 1) . ")");
        }
    }
    
    /**
     * Get mob name for logging
     */
    private function getMobName($mobType) {
        $mobNames = array(
            MOB_ZOMBIE => "Zombie",
            MOB_SKELETON => "Skeleton", 
            MOB_CREEPER => "Creeper",
            MOB_SPIDER => "Spider",
            MOB_PIG => "Pig",
            MOB_COW => "Cow",
            MOB_SHEEP => "Sheep",
            MOB_CHICKEN => "Chicken"
        );
        
        return isset($mobNames[$mobType]) ? $mobNames[$mobType] : "Unknown Mob";
    }
    
    /**
     * Get maximum health for mob type
     */
    private function getMobMaxHealth($mobType) {
        $mobHealth = array(
            MOB_ZOMBIE => 20,
            MOB_SKELETON => 20,
            MOB_CREEPER => 20,
            MOB_SPIDER => 16,
            MOB_PIG => 10,
            MOB_COW => 10,
            MOB_SHEEP => 8,
            MOB_CHICKEN => 4
        );
        
        return isset($mobHealth[$mobType]) ? $mobHealth[$mobType] : 10;
    }
    
    /**
     * Handle mob death - remove from tracking
     */
    public function handleMobDeath($data) {
        if (!isset($data['entity']) || !($data['entity'] instanceof Entity)) {
            return;
        }
        
        $entity = $data['entity'];
        if ($entity->class === ENTITY_MOB && isset($this->spawnedMobs[$entity->eid])) {
            unset($this->spawnedMobs[$entity->eid]);
            console("[MOB-SPAWN] Mob died, removed from tracking (EID: " . $entity->eid . ")");
        }
    }
    
    /**
     * Clean up mobs that are too far from all players
     */
    public function cleanupDistantMobs() {
        $players = $this->server->api->player->getAll();
        if (empty($players)) {
            return;
        }
        
        $removed = 0;
        
        foreach ($this->spawnedMobs as $mobEID => $mobData) {
            $mob = $this->server->api->entity->get($mobEID);
            if (!($mob instanceof Entity)) {
                // Mob entity no longer exists
                unset($this->spawnedMobs[$mobEID]);
                $removed++;
                continue;
            }
            
            $mobPos = array(
                'x' => $mob->x,
                'y' => $mob->y,
                'z' => $mob->z
            );
            
            $tooFar = true;
            
            // Check distance to all players
            foreach ($players as $player) {
                if (!($player instanceof Player) || !($player->entity instanceof Entity)) {
                    continue;
                }
                
                if ($player->level !== $mob->level) {
                    continue;
                }
                
                $playerPos = array(
                    'x' => $player->entity->x,
                    'y' => $player->entity->y,
                    'z' => $player->entity->z
                );
                
                $distance = $this->calculateDistance($mobPos, $playerPos);
                
                if ($distance <= self::MAX_SPAWN_RADIUS * 1.5) { // 1.5x radius for cleanup
                    $tooFar = false;
                    break;
                }
            }
            
            if ($tooFar) {
                // Remove mob that's too far from all players
                $this->server->api->entity->remove($mobEID);
                unset($this->spawnedMobs[$mobEID]);
                $removed++;
            }
        }
        
        if ($removed > 0) {
            console("[MOB-SPAWN] Cleaned up " . $removed . " distant mobs");
        }
    }
    
    /**
     * Calculate 3D distance between two positions
     */
    private function calculateDistance($pos1, $pos2) {
        return sqrt(
            pow($pos2['x'] - $pos1['x'], 2) +
            pow($pos2['y'] - $pos1['y'], 2) +
            pow($pos2['z'] - $pos1['z'], 2)
        );
    }
    
    /**
     * Get spawning statistics
     */
    public function getSpawnStats() {
        $stats = array(
            'total_mobs' => count($this->spawnedMobs),
            'mob_types' => array()
        );
        
        foreach ($this->spawnedMobs as $mobData) {
            $mobName = $this->getMobName($mobData['type']);
            if (!isset($stats['mob_types'][$mobName])) {
                $stats['mob_types'][$mobName] = 0;
            }
            $stats['mob_types'][$mobName]++;
        }
        
        return $stats;
    }
    
    /**
     * Force spawn a specific mob type (for testing/admin commands)
     */
    public function forceSpawnMob($mobType, $pos, $level) {
        if (count($this->spawnedMobs) >= self::MAX_TOTAL_MOBS) {
            return false;
        }
        
        $this->spawnMob($mobType, $pos, $level);
        return true;
    }
    
    /**
     * Remove all spawned mobs
     */
    public function removeAllMobs() {
        $removed = 0;
        
        foreach ($this->spawnedMobs as $mobEID => $mobData) {
            $this->server->api->entity->remove($mobEID);
            $removed++;
        }
        
        $this->spawnedMobs = array();
        
        console("[MOB-SPAWN] Removed all " . $removed . " spawned mobs");
        return $removed;
    }
    
    /**
     * Initialize AI for a newly spawned mob
     */
    private function initializeMobAI($mob) {
        if ($this->mobAI !== null && method_exists($this->mobAI, 'initializeMob')) {
            // Create fake event data for the AI system
            $eventData = array('entity' => $mob);
            $this->mobAI->initializeMob($eventData);
            console("[MOB-SPAWN] Initialized AI for mob EID: " . $mob->eid);
        }
    }
}
<?php

/**
 * Inventory Persistence Fix for PocketMine-MP Alpha 1.3.10
 * 
 * Fixes the inventory persistence bug by ensuring proper save/load operations:
 * - Ensures inventory is saved on disconnect
 * - Properly loads inventory on connect
 * - Handles edge cases and data corruption
 * - Provides backup and recovery mechanisms
 * 
 * @author AxoGM
 */

class InventoryPersistenceFix {
    private $server;
    private $inventoryBackups = array();
    
    public function __construct() {
        $this->server = ServerAPI::request();
        $this->initializeFix();
    }
    
    private function initializeFix() {
        // Register event handlers with high priority to ensure they run first
        $this->server->addHandler("player.spawn", array($this, "loadPlayerInventory"), 0);
        $this->server->addHandler("player.quit", array($this, "savePlayerInventory"), 0);
        $this->server->addHandler("server.save", array($this, "saveAllInventories"), 0);
        
        // Schedule periodic inventory saves as backup
        $this->server->schedule(20 * 30, array($this, "periodicInventorySave"), array(), true); // Every 30 seconds
        
        console("[INVENTORY-FIX] Inventory persistence fix initialized");
    }
    
    /**
     * Load player inventory when they join
     */
    public function loadPlayerInventory($data) {
        if (!($data instanceof Player)) {
            return true;
        }
        
        $player = $data;
        
        if (!($player->data instanceof Config)) {
            console("[INVENTORY-FIX] Warning: Player " . $player->username . " has no data config");
            return true;
        }
        
        try {
            // Load inventory from saved data
            $savedInventory = $player->data->get("inventory", array());
            $savedArmor = $player->data->get("armor", array());
            
            // Initialize inventory arrays if not already done
            if (!is_array($player->inventory)) {
                $player->inventory = array();
            }
            if (!is_array($player->armor)) {
                $player->armor = array();
            }
            
            // Load inventory items
            $this->loadInventoryItems($player, $savedInventory);
            
            // Load armor items
            $this->loadArmorItems($player, $savedArmor);
            
            // Create backup of loaded inventory
            $this->createInventoryBackup($player);
            
            console("[INVENTORY-FIX] Loaded inventory for " . $player->username . " (" . count($savedInventory) . " items, " . count($savedArmor) . " armor pieces)");
            
        } catch (Exception $e) {
            console("[INVENTORY-FIX] Error loading inventory for " . $player->username . ": " . $e->getMessage());
            $this->initializeEmptyInventory($player);
        }
        
        return true;
    }
    
    /**
     * Save player inventory when they quit
     */
    public function savePlayerInventory($data) {
        if (!($data instanceof Player)) {
            return true;
        }
        
        $player = $data;
        
        if (!($player->data instanceof Config)) {
            console("[INVENTORY-FIX] Warning: Cannot save inventory for " . $player->username . " - no data config");
            return true;
        }
        
        try {
            // Save current inventory state
            $this->saveInventoryData($player);
            
            // Force save the config file
            $player->data->save();
            
            console("[INVENTORY-FIX] Saved inventory for " . $player->username);
            
        } catch (Exception $e) {
            console("[INVENTORY-FIX] Error saving inventory for " . $player->username . ": " . $e->getMessage());
            
            // Try to restore from backup if save failed
            $this->restoreInventoryFromBackup($player);
        }
        
        return true;
    }
    
    /**
     * Load inventory items from saved data
     */
    private function loadInventoryItems($player, $savedInventory) {
        $maxSlots = ($player->gamemode & 0x01) === 0 ? PLAYER_SURVIVAL_SLOTS : PLAYER_CREATIVE_SLOTS;
        
        // Initialize all slots with air
        for ($slot = 0; $slot < $maxSlots; $slot++) {
            $player->inventory[$slot] = $this->createItem(AIR, 0, 0);
        }
        
        // Load saved items
        foreach ($savedInventory as $slot => $itemData) {
            $slot = (int) $slot;
            
            if ($slot < 0 || $slot >= $maxSlots) {
                continue; // Invalid slot
            }
            
            if (!is_array($itemData) || count($itemData) < 3) {
                continue; // Invalid item data
            }
            
            $itemId = (int) $itemData[0];
            $itemMeta = (int) $itemData[1];
            $itemCount = (int) $itemData[2];
            
            // Validate item data (more lenient for older MC versions)
            if ($itemId < 0 || $itemId > 500 || $itemCount < 0 || $itemCount > 64) {
                console("[INVENTORY-FIX] Invalid item data for " . $player->username . " slot " . $slot . ": ID=" . $itemId . ", Count=" . $itemCount);
                continue;
            }
            
            $player->inventory[$slot] = $this->createItem($itemId, $itemMeta, $itemCount);
        }
    }
    
    /**
     * Load armor items from saved data
     */
    private function loadArmorItems($player, $savedArmor) {
        // Initialize all armor slots with air
        for ($slot = 0; $slot < 4; $slot++) {
            $player->armor[$slot] = $this->createItem(AIR, 0, 0);
        }
        
        // Load saved armor
        foreach ($savedArmor as $slot => $itemData) {
            $slot = (int) $slot;
            
            if ($slot < 0 || $slot >= 4) {
                continue; // Invalid armor slot
            }
            
            if (!is_array($itemData) || count($itemData) < 2) {
                continue; // Invalid armor data
            }
            
            $itemId = (int) $itemData[0];
            $itemMeta = (int) $itemData[1];
            
            // Validate armor data (more lenient for older MC versions)
            if ($itemId < 0 || $itemId > 500) {
                console("[INVENTORY-FIX] Invalid armor data for " . $player->username . " slot " . $slot . ": ID=" . $itemId);
                continue;
            }
            
            $player->armor[$slot] = $this->createItem($itemId, $itemMeta, 1);
        }
    }
    
    /**
     * Save inventory data to player config
     */
    private function saveInventoryData($player) {
        if (!is_array($player->inventory) || !is_array($player->armor)) {
            console("[INVENTORY-FIX] Warning: Invalid inventory arrays for " . $player->username);
            return;
        }
        
        // Save inventory
        $inventoryData = array();
        $maxSlots = ($player->gamemode & 0x01) === 0 ? PLAYER_SURVIVAL_SLOTS : PLAYER_CREATIVE_SLOTS;
        
        foreach ($player->inventory as $slot => $item) {
            $slot = (int) $slot;
            
            if ($slot >= $maxSlots) {
                continue; // Skip invalid slots
            }
            
            if ($this->isValidItem($item) && $item->getID() !== AIR && $item->count > 0) {
                $inventoryData[$slot] = array(
                    $item->getID(),
                    $item->getMetadata(),
                    $item->count
                );
            }
        }
        
        // Save armor
        $armorData = array();
        foreach ($player->armor as $slot => $item) {
            $slot = (int) $slot;
            
            if ($slot >= 4) {
                continue; // Skip invalid armor slots
            }
            
            if ($this->isValidItem($item) && $item->getID() !== AIR) {
                $armorData[$slot] = array(
                    $item->getID(),
                    $item->getMetadata()
                );
            }
        }
        
        // Update player data
        $player->data->set("inventory", $inventoryData);
        $player->data->set("armor", $armorData);
        
        // Also save other important data
        if ($player->entity instanceof Entity) {
            $player->data->set("position", array(
                "level" => $player->entity->level->getName(),
                "x" => $player->entity->x,
                "y" => $player->entity->y,
                "z" => $player->entity->z,
            ));
            
            $player->data->set("health", $player->entity->getHealth());
        }
        
        $player->data->set("gamemode", $player->gamemode);
        $player->data->set("lastSave", time());
    }
    
    /**
     * Create an item object (compatibility with different item systems)
     */
    private function createItem($id, $meta, $count) {
        // Try to use BlockAPI if available
        if (class_exists('BlockAPI') && method_exists('BlockAPI', 'getItem')) {
            return BlockAPI::getItem($id, $meta, $count);
        }
        
        // Try to use ServerAPI item creation
        if (method_exists($this->server->api, 'item') && method_exists($this->server->api->item, 'get')) {
            return $this->server->api->item->get($id, $meta, $count);
        }
        
        // Fallback: Create a simple item-like object
        $item = new stdClass();
        $item->id = $id;
        $item->meta = $meta;
        $item->count = $count;
        
        // Add methods for compatibility
        $item->getID = function() use ($id) { return $id; };
        $item->getMetadata = function() use ($meta) { return $meta; };
        
        return $item;
    }
    
    /**
     * Check if an item object is valid
     */
    private function isValidItem($item) {
        if (!is_object($item)) {
            return false;
        }
        
        // Check if it has required methods or properties
        if (method_exists($item, 'getID') && method_exists($item, 'getMetadata')) {
            return true;
        }
        
        if (isset($item->id) && isset($item->meta) && isset($item->count)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Initialize empty inventory for new players or corrupted data
     */
    private function initializeEmptyInventory($player) {
        $maxSlots = ($player->gamemode & 0x01) === 0 ? PLAYER_SURVIVAL_SLOTS : PLAYER_CREATIVE_SLOTS;
        
        $player->inventory = array();
        for ($slot = 0; $slot < $maxSlots; $slot++) {
            $player->inventory[$slot] = $this->createItem(AIR, 0, 0);
        }
        
        $player->armor = array();
        for ($slot = 0; $slot < 4; $slot++) {
            $player->armor[$slot] = $this->createItem(AIR, 0, 0);
        }
        
        console("[INVENTORY-FIX] Initialized empty inventory for " . $player->username);
    }
    
    /**
     * Create backup of player inventory
     */
    private function createInventoryBackup($player) {
        if (!is_array($player->inventory) || !is_array($player->armor)) {
            return;
        }
        
        $backup = array(
            'inventory' => array(),
            'armor' => array(),
            'timestamp' => time()
        );
        
        // Backup inventory
        foreach ($player->inventory as $slot => $item) {
            if ($this->isValidItem($item)) {
                $backup['inventory'][$slot] = array(
                    $item->getID(),
                    $item->getMetadata(),
                    $item->count
                );
            }
        }
        
        // Backup armor
        foreach ($player->armor as $slot => $item) {
            if ($this->isValidItem($item)) {
                $backup['armor'][$slot] = array(
                    $item->getID(),
                    $item->getMetadata()
                );
            }
        }
        
        $this->inventoryBackups[$player->CID] = $backup;
    }
    
    /**
     * Restore inventory from backup
     */
    private function restoreInventoryFromBackup($player) {
        if (!isset($this->inventoryBackups[$player->CID])) {
            return false;
        }
        
        $backup = $this->inventoryBackups[$player->CID];
        
        try {
            $this->loadInventoryItems($player, $backup['inventory']);
            $this->loadArmorItems($player, $backup['armor']);
            
            console("[INVENTORY-FIX] Restored inventory from backup for " . $player->username);
            return true;
            
        } catch (Exception $e) {
            console("[INVENTORY-FIX] Failed to restore inventory from backup for " . $player->username . ": " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Save all online player inventories
     */
    public function saveAllInventories() {
        $saved = 0;
        
        foreach ($this->server->clients as $player) {
            if ($player instanceof Player && $player->loggedIn) {
                try {
                    $this->saveInventoryData($player);
                    if ($player->data instanceof Config) {
                        $player->data->save();
                    }
                    $saved++;
                } catch (Exception $e) {
                    console("[INVENTORY-FIX] Error saving inventory for " . $player->username . ": " . $e->getMessage());
                }
            }
        }
        
        if ($saved > 0) {
            console("[INVENTORY-FIX] Saved inventories for " . $saved . " players");
        }
    }
    
    /**
     * Periodic inventory save (backup mechanism)
     */
    public function periodicInventorySave() {
        $this->saveAllInventories();
    }
    
    /**
     * Validate and repair player inventory
     */
    public function validateAndRepairInventory($player) {
        $repaired = false;
        
        // Check inventory array
        if (!is_array($player->inventory)) {
            $player->inventory = array();
            $repaired = true;
        }
        
        // Check armor array
        if (!is_array($player->armor)) {
            $player->armor = array();
            $repaired = true;
        }
        
        $maxSlots = ($player->gamemode & 0x01) === 0 ? PLAYER_SURVIVAL_SLOTS : PLAYER_CREATIVE_SLOTS;
        
        // Validate inventory slots
        for ($slot = 0; $slot < $maxSlots; $slot++) {
            if (!isset($player->inventory[$slot]) || !$this->isValidItem($player->inventory[$slot])) {
                $player->inventory[$slot] = $this->createItem(AIR, 0, 0);
                $repaired = true;
            }
        }
        
        // Validate armor slots
        for ($slot = 0; $slot < 4; $slot++) {
            if (!isset($player->armor[$slot]) || !$this->isValidItem($player->armor[$slot])) {
                $player->armor[$slot] = $this->createItem(AIR, 0, 0);
                $repaired = true;
            }
        }
        
        if ($repaired) {
            console("[INVENTORY-FIX] Repaired inventory for " . $player->username);
            $this->createInventoryBackup($player);
        }
        
        return $repaired;
    }
    
    /**
     * Get inventory statistics for debugging
     */
    public function getInventoryStats() {
        $stats = array(
            'backups_created' => count($this->inventoryBackups),
            'players_with_backups' => array()
        );
        
        foreach ($this->inventoryBackups as $cid => $backup) {
            $player = isset($this->server->clients[$cid]) ? $this->server->clients[$cid] : null;
            if ($player instanceof Player) {
                $stats['players_with_backups'][] = $player->username;
            }
        }
        
        return $stats;
    }
    
    /**
     * Clean up old backups
     */
    public function cleanupOldBackups() {
        $currentTime = time();
        $maxAge = 3600; // 1 hour
        
        foreach ($this->inventoryBackups as $cid => $backup) {
            if (($currentTime - $backup['timestamp']) > $maxAge) {
                unset($this->inventoryBackups[$cid]);
            }
        }
    }
}
<?php

/**
 * Player Identification System for PocketMine-MP Alpha 1.3.10
 * 
 * Provides unique player identification and name disambiguation:
 * - Generates unique IDs for players
 * - Handles duplicate usernames
 * - Tracks players across IP changes
 * - Maintains persistent player data
 * 
 * @author AxoGM
 */

class PlayerIdentificationSystem {
    private $server;
    private $ipToUidMap = array();
    private $uidToPlayerMap = array();
    private $usernameToUidMap = array();
    private $onlineUsernames = array();
    
    const UID_LENGTH = 8;
    const UID_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const IP_MAP_FILE = 'ip_to_uid_map.json';
    const USERNAME_MAP_FILE = 'username_to_uid_map.json';
    
    public function __construct() {
        $this->server = ServerAPI::request();
        $this->initializeSystem();
        $this->loadMappings();
    }
    
    private function initializeSystem() {
        // Register event handlers
        $this->server->addHandler("player.preconnect", array($this, "handlePlayerConnect"), 1);
        $this->server->addHandler("player.join", array($this, "handlePlayerJoin"), 1);
        $this->server->addHandler("player.quit", array($this, "handlePlayerQuit"), 1);
        
        console("[PLAYER-ID] Player identification system initialized");
    }
    
    /**
     * Load existing mappings from files
     */
    private function loadMappings() {
        // Load IP to UID mapping
        $ipMapFile = DATA_PATH . self::IP_MAP_FILE;
        if (file_exists($ipMapFile)) {
            $data = json_decode(file_get_contents($ipMapFile), true);
            if (is_array($data)) {
                $this->ipToUidMap = $data;
            }
        }
        
        // Load username to UID mapping
        $usernameMapFile = DATA_PATH . self::USERNAME_MAP_FILE;
        if (file_exists($usernameMapFile)) {
            $data = json_decode(file_get_contents($usernameMapFile), true);
            if (is_array($data)) {
                $this->usernameToUidMap = $data;
            }
        }
        
        console("[PLAYER-ID] Loaded " . count($this->ipToUidMap) . " IP mappings and " . count($this->usernameToUidMap) . " username mappings");
    }
    
    /**
     * Save mappings to files
     */
    private function saveMappings() {
        // Save IP to UID mapping
        $ipMapFile = DATA_PATH . self::IP_MAP_FILE;
        file_put_contents($ipMapFile, json_encode($this->ipToUidMap, JSON_PRETTY_PRINT));
        
        // Save username to UID mapping
        $usernameMapFile = DATA_PATH . self::USERNAME_MAP_FILE;
        file_put_contents($usernameMapFile, json_encode($this->usernameToUidMap, JSON_PRETTY_PRINT));
    }
    
    /**
     * Handle player connection - assign UID and resolve username conflicts
     */
    public function handlePlayerConnect($data) {
        if (!isset($data['player']) || !($data['player'] instanceof Player)) {
            return true;
        }
        
        $player = $data['player'];
        $ip = $player->ip;
        $originalUsername = $player->username;
        
        // Get or create UID for this player
        $uid = $this->getOrCreateUID($ip, $originalUsername);
        
        // Resolve username conflicts
        $finalUsername = $this->resolveUsernameConflict($originalUsername, $uid);
        
        // Update player data
        $player->username = $finalUsername;
        $player->iusername = strtolower($finalUsername);
        
        // Store UID in player object for later use
        $player->uniqueID = $uid;
        
        // Update mappings
        $this->uidToPlayerMap[$uid] = $player;
        $this->onlineUsernames[strtolower($finalUsername)] = $uid;
        
        // Notify player if username was changed
        if ($finalUsername !== $originalUsername) {
            console("[PLAYER-ID] Username conflict resolved: " . $originalUsername . " -> " . $finalUsername . " (UID: " . $uid . ")");
        }
        
        console("[PLAYER-ID] Player connected: " . $finalUsername . " (UID: " . $uid . ", IP: " . $ip . ")");
        
        return true;
    }
    
    /**
     * Handle player join - load player data using UID
     */
    public function handlePlayerJoin($data) {
        if (!($data instanceof Player)) {
            return true;
        }
        
        $player = $data;
        
        if (!isset($player->uniqueID)) {
            console("[PLAYER-ID] Warning: Player " . $player->username . " has no UID assigned");
            return true;
        }
        
        // Load player data using UID instead of username
        $player->data = $this->getPlayerDataByUID($player->uniqueID, $player->username);
        
        return true;
    }
    
    /**
     * Handle player quit - cleanup and save data
     */
    public function handlePlayerQuit($data) {
        if (!($data instanceof Player)) {
            return true;
        }
        
        $player = $data;
        
        if (isset($player->uniqueID)) {
            // Remove from online tracking
            unset($this->uidToPlayerMap[$player->uniqueID]);
            unset($this->onlineUsernames[strtolower($player->username)]);
            
            // Save player data using UID
            if ($player->data instanceof Config) {
                $this->savePlayerDataByUID($player->uniqueID, $player->data);
            }
            
            console("[PLAYER-ID] Player disconnected: " . $player->username . " (UID: " . $player->uniqueID . ")");
        }
        
        // Save mappings
        $this->saveMappings();
        
        return true;
    }
    
    /**
     * Get existing UID or create new one for player
     */
    private function getOrCreateUID($ip, $username) {
        $lowerUsername = strtolower($username);
        
        // First, check if this IP already has a UID
        if (isset($this->ipToUidMap[$ip])) {
            $uid = $this->ipToUidMap[$ip];
            console("[PLAYER-ID] Returning player detected by IP: " . $username . " (UID: " . $uid . ")");
            return $uid;
        }
        
        // Check if this username has been used before
        if (isset($this->usernameToUidMap[$lowerUsername])) {
            $uid = $this->usernameToUidMap[$lowerUsername];
            
            // Associate this IP with the existing UID
            $this->ipToUidMap[$ip] = $uid;
            
            console("[PLAYER-ID] Returning player detected by username: " . $username . " (UID: " . $uid . ")");
            return $uid;
        }
        
        // Create new UID for new player
        $uid = $this->generateUID();
        
        // Store mappings
        $this->ipToUidMap[$ip] = $uid;
        $this->usernameToUidMap[$lowerUsername] = $uid;
        
        console("[PLAYER-ID] New player registered: " . $username . " (UID: " . $uid . ")");
        
        return $uid;
    }
    
    /**
     * Resolve username conflicts by appending numbers
     */
    private function resolveUsernameConflict($originalUsername, $uid) {
        $lowerOriginal = strtolower($originalUsername);
        
        // Check if username is already in use by a different player
        if (isset($this->onlineUsernames[$lowerOriginal])) {
            $existingUID = $this->onlineUsernames[$lowerOriginal];
            
            // If it's the same player (same UID), no conflict
            if ($existingUID === $uid) {
                return $originalUsername;
            }
            
            // Find available username with number suffix
            $counter = 1;
            do {
                $newUsername = $originalUsername . $counter;
                $lowerNew = strtolower($newUsername);
                $counter++;
            } while (isset($this->onlineUsernames[$lowerNew]) && $counter <= 999);
            
            if ($counter > 999) {
                // Fallback to UID-based username
                $newUsername = "Player_" . substr($uid, 0, 6);
            }
            
            return $newUsername;
        }
        
        return $originalUsername;
    }
    
    /**
     * Generate a unique random UID
     */
    private function generateUID() {
        do {
            $uid = '_'; // Start with underscore to distinguish from regular usernames
            for ($i = 0; $i < self::UID_LENGTH - 1; $i++) {
                $uid .= self::UID_CHARS[mt_rand(0, strlen(self::UID_CHARS) - 1)];
            }
        } while ($this->uidExists($uid));
        
        return $uid;
    }
    
    /**
     * Check if UID already exists
     */
    private function uidExists($uid) {
        // Check in IP mapping
        if (in_array($uid, $this->ipToUidMap)) {
            return true;
        }
        
        // Check in username mapping
        if (in_array($uid, $this->usernameToUidMap)) {
            return true;
        }
        
        // Check if player data file exists
        $dataFile = DATA_PATH . "players/" . $uid . ".yml";
        if (file_exists($dataFile)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Get player data by UID
     */
    private function getPlayerDataByUID($uid, $displayName) {
        $dataFile = DATA_PATH . "players/" . $uid . ".yml";
        
        $default = array(
            "uniqueID" => $uid,
            "displayName" => $displayName,
            "caseusername" => $displayName,
            "position" => array(
                "level" => $this->server->spawn->level->getName(),
                "x" => $this->server->spawn->x,
                "y" => $this->server->spawn->y,
                "z" => $this->server->spawn->z,
            ),
            "spawn" => array(
                "level" => $this->server->spawn->level->getName(),
                "x" => $this->server->spawn->x,
                "y" => $this->server->spawn->y,
                "z" => $this->server->spawn->z,
            ),
            "inventory" => array_fill(0, PLAYER_SURVIVAL_SLOTS, array(AIR, 0, 0)),
            "armor" => array_fill(0, 4, array(AIR, 0)),
            "gamemode" => $this->server->gamemode,
            "health" => 20,
            "lastIP" => "",
            "lastID" => 0,
            "firstJoin" => time(),
            "lastSeen" => time(),
        );
        
        if (!file_exists($dataFile)) {
            console("[PLAYER-ID] Creating new player data for UID: " . $uid);
            $data = new Config($dataFile, CONFIG_YAML, $default);
            $data->save();
        } else {
            $data = new Config($dataFile, CONFIG_YAML, $default);
            // Update display name in case it changed
            $data->set("displayName", $displayName);
            $data->set("caseusername", $displayName);
        }
        
        // Update last seen time
        $data->set("lastSeen", time());
        
        return $data;
    }
    
    /**
     * Save player data by UID
     */
    private function savePlayerDataByUID($uid, $data) {
        $data->set("uniqueID", $uid);
        $data->set("lastSeen", time());
        $data->save();
    }
    
    /**
     * Get player by UID
     */
    public function getPlayerByUID($uid) {
        return isset($this->uidToPlayerMap[$uid]) ? $this->uidToPlayerMap[$uid] : null;
    }
    
    /**
     * Get UID by IP address
     */
    public function getUIDByIP($ip) {
        return isset($this->ipToUidMap[$ip]) ? $this->ipToUidMap[$ip] : null;
    }
    
    /**
     * Get UID by username
     */
    public function getUIDByUsername($username) {
        $lowerUsername = strtolower($username);
        return isset($this->usernameToUidMap[$lowerUsername]) ? $this->usernameToUidMap[$lowerUsername] : null;
    }
    
    /**
     * Get all UIDs for debugging
     */
    public function getAllUIDs() {
        $uids = array();
        
        foreach ($this->ipToUidMap as $uid) {
            $uids[$uid] = true;
        }
        
        foreach ($this->usernameToUidMap as $uid) {
            $uids[$uid] = true;
        }
        
        return array_keys($uids);
    }
    
    /**
     * Get system statistics
     */
    public function getStats() {
        return array(
            'total_players' => count($this->getAllUIDs()),
            'online_players' => count($this->uidToPlayerMap),
            'ip_mappings' => count($this->ipToUidMap),
            'username_mappings' => count($this->usernameToUidMap)
        );
    }
    
    /**
     * Clean up old mappings (for maintenance)
     */
    public function cleanupOldMappings($daysOld = 30) {
        $cutoffTime = time() - ($daysOld * 24 * 60 * 60);
        $cleaned = 0;
        
        // Get all player data files
        $playerDir = DATA_PATH . "players/";
        if (is_dir($playerDir)) {
            $files = scandir($playerDir);
            
            foreach ($files as $file) {
                if (substr($file, -4) === '.yml' && substr($file, 0, 1) === '_') {
                    $uid = substr($file, 0, -4);
                    $filePath = $playerDir . $file;
                    
                    $data = new Config($filePath, CONFIG_YAML);
                    $lastSeen = $data->get("lastSeen", 0);
                    
                    if ($lastSeen < $cutoffTime) {
                        // Remove from mappings
                        foreach ($this->ipToUidMap as $ip => $mappedUID) {
                            if ($mappedUID === $uid) {
                                unset($this->ipToUidMap[$ip]);
                            }
                        }
                        
                        foreach ($this->usernameToUidMap as $username => $mappedUID) {
                            if ($mappedUID === $uid) {
                                unset($this->usernameToUidMap[$username]);
                            }
                        }
                        
                        $cleaned++;
                    }
                }
            }
        }
        
        if ($cleaned > 0) {
            $this->saveMappings();
            console("[PLAYER-ID] Cleaned up " . $cleaned . " old player mappings");
        }
        
        return $cleaned;
    }
}
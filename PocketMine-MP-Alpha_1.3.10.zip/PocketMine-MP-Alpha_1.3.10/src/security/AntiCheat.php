<?php

/**
 * Anti-Cheat System for PocketMine-MP Alpha 1.3.10
 * 
 * This system implements server-side checks to detect and prevent common cheating methods:
 * - Fly/Noclip detection
 * - Speed hack detection  
 * - Impossible reach detection
 * 
 * @author AxoGM
 */

class AntiCheat {
    private $server;
    private $violations = array();
    private $lastPositions = array();
    private $lastMovementTime = array();
    
    // Configuration constants
    const MAX_SPEED_SURVIVAL = 7.0; // blocks per second
    const MAX_SPEED_CREATIVE = 15.0; // blocks per second  
    const MAX_REACH_DISTANCE = 6.0; // blocks
    const MAX_VERTICAL_SPEED = 12.0; // blocks per second (accounting for jumping)
    const VIOLATION_THRESHOLD = 5; // violations before action
    const CHECK_INTERVAL = 0.5; // seconds between position checks
    
    public function __construct() {
        $this->server = ServerAPI::request();
        $this->initializeAntiCheat();
    }
    
    private function initializeAntiCheat() {
        // Register event handlers for player actions
        $this->server->addHandler("player.move", array($this, "checkMovement"), 1);
        $this->server->addHandler("player.block.break", array($this, "checkReach"), 1);
        $this->server->addHandler("player.block.place", array($this, "checkReach"), 1);
        $this->server->addHandler("player.interact", array($this, "checkReach"), 1);
        $this->server->addHandler("player.join", array($this, "initializePlayer"), 1);
        $this->server->addHandler("player.quit", array($this, "cleanupPlayer"), 1);
        
        console("[SECURITY] Anti-cheat system initialized");
    }
    
    /**
     * Initialize tracking data for a new player
     */
    public function initializePlayer($data) {
        if (!($data instanceof Player)) return;
        
        $playerId = $data->CID;
        $this->violations[$playerId] = 0;
        $this->lastPositions[$playerId] = null;
        $this->lastMovementTime[$playerId] = microtime(true);
    }
    
    /**
     * Clean up tracking data when player leaves
     */
    public function cleanupPlayer($data) {
        if (!($data instanceof Player)) return;
        
        $playerId = $data->CID;
        unset($this->violations[$playerId]);
        unset($this->lastPositions[$playerId]);
        unset($this->lastMovementTime[$playerId]);
    }
    
    /**
     * Check player movement for speed hacks and fly/noclip
     */
    public function checkMovement($data) {
        // Handle different data formats - sometimes it's an Entity, sometimes an array
        if ($data instanceof Entity && isset($data->player) && $data->player instanceof Player) {
            $player = $data->player;
        } elseif (isset($data['player']) && $data['player'] instanceof Player) {
            $player = $data['player'];
        } else {
            return true; // Can't process this data format
        }
        
        if (!($player instanceof Player)) {
            return true;
        }
        $playerId = $player->CID;
        
        // Skip checks for creative mode players (less restrictive)
        if (($player->gamemode & 0x01) === 0x01) {
            return $this->checkCreativeMovement($player);
        }
        
        return $this->checkSurvivalMovement($player);
    }
    
    /**
     * Check movement for survival mode players
     */
    private function checkSurvivalMovement($player) {
        $playerId = $player->CID;
        $currentTime = microtime(true);
        
        if (!isset($this->lastPositions[$playerId]) || !isset($this->lastMovementTime[$playerId])) {
            $this->updatePlayerPosition($player);
            return true;
        }
        
        $timeDiff = $currentTime - $this->lastMovementTime[$playerId];
        if ($timeDiff < self::CHECK_INTERVAL) {
            return true; // Too soon to check
        }
        
        $lastPos = $this->lastPositions[$playerId];
        $currentPos = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y, 
            'z' => $player->entity->z
        );
        
        // Calculate movement distance and speed
        $horizontalDistance = sqrt(
            pow($currentPos['x'] - $lastPos['x'], 2) + 
            pow($currentPos['z'] - $lastPos['z'], 2)
        );
        $verticalDistance = $currentPos['y'] - $lastPos['y'];
        $speed = $horizontalDistance / $timeDiff;
        $verticalSpeed = abs($verticalDistance) / $timeDiff;
        
        $violation = false;
        $reason = "";
        
        // Check for speed hacks
        if ($speed > self::MAX_SPEED_SURVIVAL) {
            $violation = true;
            $reason = "Speed hack detected (Speed: " . round($speed, 2) . " b/s)";
        }
        
        // Check for fly/noclip (excessive vertical movement without ground contact)
        if ($verticalSpeed > self::MAX_VERTICAL_SPEED && $verticalDistance > 0) {
            if (!$this->isPlayerOnGround($player) && !$this->isPlayerInWater($player)) {
                $violation = true;
                $reason = "Fly/Noclip detected (Vertical speed: " . round($verticalSpeed, 2) . " b/s)";
            }
        }
        
        // Noclip detection disabled for now due to false positives
        // TODO: Improve noclip detection algorithm
        /*
        if ($this->isMovingThroughBlocks($lastPos, $currentPos, $player->level)) {
            $violation = true;
            $reason = "Noclip detected (Moving through solid blocks)";
        }
        */
        
        if ($violation) {
            return $this->handleViolation($player, $reason);
        }
        
        $this->updatePlayerPosition($player);
        return true;
    }
    
    /**
     * Check movement for creative mode players (more lenient)
     */
    private function checkCreativeMovement($player) {
        $playerId = $player->CID;
        $currentTime = microtime(true);
        
        if (!isset($this->lastPositions[$playerId]) || !isset($this->lastMovementTime[$playerId])) {
            $this->updatePlayerPosition($player);
            return true;
        }
        
        $timeDiff = $currentTime - $this->lastMovementTime[$playerId];
        if ($timeDiff < self::CHECK_INTERVAL) {
            return true;
        }
        
        $lastPos = $this->lastPositions[$playerId];
        $currentPos = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y,
            'z' => $player->entity->z
        );
        
        $horizontalDistance = sqrt(
            pow($currentPos['x'] - $lastPos['x'], 2) + 
            pow($currentPos['z'] - $lastPos['z'], 2)
        );
        $speed = $horizontalDistance / $timeDiff;
        
        // More lenient speed check for creative mode
        if ($speed > self::MAX_SPEED_CREATIVE) {
            return $this->handleViolation($player, "Excessive speed in creative mode: " . round($speed, 2) . " b/s");
        }
        
        $this->updatePlayerPosition($player);
        return true;
    }
    
    /**
     * Check reach distance for block interactions
     */
    public function checkReach($data) {
        if (!isset($data['player']) || !($data['player'] instanceof Player)) {
            return true;
        }
        
        $player = $data['player'];
        
        // Get target position from the event data
        $targetPos = null;
        if (isset($data['x']) && isset($data['y']) && isset($data['z'])) {
            $targetPos = array(
                'x' => $data['x'],
                'y' => $data['y'], 
                'z' => $data['z']
            );
        } elseif (isset($data['target']) && $data['target'] instanceof Vector3) {
            $targetPos = array(
                'x' => $data['target']->x,
                'y' => $data['target']->y,
                'z' => $data['target']->z
            );
        }
        
        if ($targetPos === null) {
            return true; // Can't check without target position
        }
        
        $playerPos = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y,
            'z' => $player->entity->z
        );
        
        $distance = sqrt(
            pow($targetPos['x'] - $playerPos['x'], 2) +
            pow($targetPos['y'] - $playerPos['y'], 2) +
            pow($targetPos['z'] - $playerPos['z'], 2)
        );
        
        if ($distance > self::MAX_REACH_DISTANCE) {
            return $this->handleViolation($player, "Impossible reach detected (Distance: " . round($distance, 2) . " blocks)");
        }
        
        return true;
    }
    
    /**
     * Update stored player position
     */
    private function updatePlayerPosition($player) {
        $playerId = $player->CID;
        $this->lastPositions[$playerId] = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y,
            'z' => $player->entity->z
        );
        $this->lastMovementTime[$playerId] = microtime(true);
    }
    
    /**
     * Check if player is on solid ground
     */
    private function isPlayerOnGround($player) {
        $level = $player->level;
        $x = floor($player->entity->x);
        $y = floor($player->entity->y - 1); // Block below player
        $z = floor($player->entity->z);
        
        $blockData = $level->level->getBlock($x, $y, $z);
        $blockId = $blockData[0];
        return $blockId !== AIR && $blockId !== WATER && $blockId !== STILL_WATER;
    }
    
    /**
     * Check if player is in water
     */
    private function isPlayerInWater($player) {
        $level = $player->level;
        $x = floor($player->entity->x);
        $y = floor($player->entity->y);
        $z = floor($player->entity->z);
        
        $blockData = $level->level->getBlock($x, $y, $z);
        $blockId = $blockData[0];
        return $blockId === WATER || $blockId === STILL_WATER;
    }
    
    /**
     * Check if player is moving through solid blocks
     */
    private function isMovingThroughBlocks($from, $to, $level) {
        // Calculate movement distance
        $distance = sqrt(
            pow($to['x'] - $from['x'], 2) +
            pow($to['y'] - $from['y'], 2) +
            pow($to['z'] - $from['z'], 2)
        );
        
        // Skip check for very small movements to avoid false positives
        if ($distance < 0.5) {
            return false;
        }
        
        // Only check the player's head and feet positions, not the entire path
        $positions = array(
            array('x' => $to['x'], 'y' => $to['y'], 'z' => $to['z']), // Head
            array('x' => $to['x'], 'y' => $to['y'] - 1, 'z' => $to['z']) // Feet
        );
        
        foreach ($positions as $pos) {
            $x = floor($pos['x']);
            $y = floor($pos['y']);
            $z = floor($pos['z']);
            
            // Skip if coordinates are invalid
            if ($y < 0 || $y > 127) {
                continue;
            }
            
            try {
                $blockData = $level->level->getBlock($x, $y, $z);
                $blockId = $blockData[0];
                
                // Check if it's a solid block (not air, water, etc.)
                if ($this->isSolidBlock($blockId)) {
                    return true;
                }
            } catch (Exception $e) {
                // If we can't check the block, assume it's safe
                continue;
            }
        }
        
        return false;
    }
    
    /**
     * Check if a block ID represents a solid block
     */
    private function isSolidBlock($blockId) {
        $nonSolidBlocks = array(
            AIR, WATER, STILL_WATER, LAVA, STILL_LAVA,
            TALL_GRASS, DANDELION, ROSE, BROWN_MUSHROOM, RED_MUSHROOM,
            TORCH, FIRE, REEDS, SAPLING
        );
        
        return !in_array($blockId, $nonSolidBlocks);
    }
    
    /**
     * Handle a detected violation
     */
    private function handleViolation($player, $reason) {
        $playerId = $player->CID;
        
        if (!isset($this->violations[$playerId])) {
            $this->violations[$playerId] = 0;
        }
        
        $this->violations[$playerId]++;
        
        // Log the violation
        console("[ANTICHEAT] " . $player->username . " (" . $player->ip . "): " . $reason . " (Violation #" . $this->violations[$playerId] . ")");
        
        // Take action based on violation count
        if ($this->violations[$playerId] >= self::VIOLATION_THRESHOLD) {
            // Kick the player
            $player->close("Anti-cheat violation: " . $reason);
            console("[ANTICHEAT] " . $player->username . " kicked for repeated violations");
            return false;
        } else {
            // Send warning to player
            $player->sendChat("§c[AntiCheat] Warning: " . $reason);
            
            // Teleport player back to last valid position if available
            if (isset($this->lastPositions[$playerId])) {
                $lastPos = $this->lastPositions[$playerId];
                $player->teleport(new Vector3($lastPos['x'], $lastPos['y'], $lastPos['z']));
            }
        }
        
        return false; // Block the action that triggered the violation
    }
    
    /**
     * Get violation count for a player
     */
    public function getViolationCount($player) {
        return isset($this->violations[$player->CID]) ? $this->violations[$player->CID] : 0;
    }
    
    /**
     * Reset violations for a player
     */
    public function resetViolations($player) {
        $this->violations[$player->CID] = 0;
    }
}
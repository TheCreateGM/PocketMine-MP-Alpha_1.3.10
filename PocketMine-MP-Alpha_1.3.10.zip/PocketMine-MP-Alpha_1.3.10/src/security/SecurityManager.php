<?php

/**
 * Security Manager for PocketMine-MP Alpha 1.3.10
 * 
 * Handles general server security including:
 * - RCON security validation
 * - Input sanitization and validation
 * - Connection rate limiting
 * - Suspicious activity detection
 * 
 * @author AxoGM
 */

class SecurityManager {
    private $server;
    private $connectionAttempts = array();
    private $bannedIPs = array();
    private $suspiciousActivity = array();
    
    // Security configuration
    const MAX_CONNECTIONS_PER_IP = 3;
    const CONNECTION_TIMEOUT = 300; // 5 minutes
    const MAX_LOGIN_ATTEMPTS = 5;
    const BRUTE_FORCE_TIMEOUT = 1800; // 30 minutes
    
    public function __construct() {
        $this->server = ServerAPI::request();
        $this->initializeSecurity();
        $this->loadBannedIPs();
    }
    
    private function initializeSecurity() {
        // Register security event handlers
        $this->server->addHandler("player.preconnect", array($this, "validateConnection"), 1);
        $this->server->addHandler("player.prelogin", array($this, "validateLogin"), 1);
        $this->server->addHandler("server.command", array($this, "validateCommand"), 1);
        
        // Schedule cleanup tasks
        $this->server->schedule(20 * 60, array($this, "cleanupConnections"), array(), true); // Every minute
        
        console("[SECURITY] Security manager initialized");
    }
    
    /**
     * Load banned IPs from file
     */
    private function loadBannedIPs() {
        $banFile = DATA_PATH . "banned-ips.txt";
        if (file_exists($banFile)) {
            $lines = file($banFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                $line = trim($line);
                if (!empty($line) && substr($line, 0, 1) !== '#') {
                    $this->bannedIPs[$line] = true;
                }
            }
        }
    }
    
    /**
     * Validate incoming connections
     */
    public function validateConnection($data) {
        if (!isset($data['ip'])) {
            return false;
        }
        
        $ip = $data['ip'];
        
        // Check if IP is banned
        if (isset($this->bannedIPs[$ip])) {
            console("[SECURITY] Blocked connection from banned IP: " . $ip);
            return false;
        }
        
        // Check connection rate limiting
        if (!$this->checkConnectionRate($ip)) {
            console("[SECURITY] Connection rate limit exceeded for IP: " . $ip);
            return false;
        }
        
        // Check for suspicious patterns
        if ($this->detectSuspiciousConnection($ip)) {
            console("[SECURITY] Suspicious connection pattern detected from IP: " . $ip);
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate login attempts
     */
    public function validateLogin($data) {
        if (!isset($data['player']) || !($data['player'] instanceof Player)) {
            return false;
        }
        
        $player = $data['player'];
        $ip = $player->ip;
        
        // Validate username format
        if (!$this->isValidUsername($player->username)) {
            console("[SECURITY] Invalid username format from " . $ip . ": " . $player->username);
            $player->close("Invalid username format");
            return false;
        }
        
        // Check for brute force attempts
        if ($this->isBruteForceAttempt($ip)) {
            console("[SECURITY] Brute force attempt detected from " . $ip);
            $player->close("Too many login attempts");
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate server commands for security
     */
    public function validateCommand($data) {
        if (!isset($data['command']) || !isset($data['issuer'])) {
            return true;
        }
        
        $command = $data['command'];
        $issuer = $data['issuer'];
        
        // Sanitize command input
        $command = $this->sanitizeInput($command);
        
        // Check for dangerous commands
        if ($this->isDangerousCommand($command)) {
            if ($issuer instanceof Player) {
                console("[SECURITY] Dangerous command attempt by " . $issuer->username . " (" . $issuer->ip . "): " . $command);
                $issuer->sendChat("§cAccess denied: Insufficient permissions");
            }
            return false;
        }
        
        // Log administrative commands
        if ($this->isAdminCommand($command)) {
            $issuerName = ($issuer instanceof Player) ? $issuer->username . " (" . $issuer->ip . ")" : "Console";
            console("[SECURITY] Admin command executed by " . $issuerName . ": " . $command);
        }
        
        return true;
    }
    
    /**
     * Check connection rate limiting
     */
    private function checkConnectionRate($ip) {
        $currentTime = time();
        
        if (!isset($this->connectionAttempts[$ip])) {
            $this->connectionAttempts[$ip] = array();
        }
        
        // Remove old connection attempts
        $this->connectionAttempts[$ip] = array_filter(
            $this->connectionAttempts[$ip],
            function($timestamp) use ($currentTime) {
                return ($currentTime - $timestamp) < self::CONNECTION_TIMEOUT;
            }
        );
        
        // Check if limit exceeded
        if (count($this->connectionAttempts[$ip]) >= self::MAX_CONNECTIONS_PER_IP) {
            return false;
        }
        
        // Record this connection attempt
        $this->connectionAttempts[$ip][] = $currentTime;
        
        return true;
    }
    
    /**
     * Detect suspicious connection patterns
     */
    private function detectSuspiciousConnection($ip) {
        // Check for rapid connection attempts from same IP
        if (isset($this->connectionAttempts[$ip])) {
            $recentAttempts = array_filter(
                $this->connectionAttempts[$ip],
                function($timestamp) {
                    return (time() - $timestamp) < 60; // Last minute
                }
            );
            
            if (count($recentAttempts) > 10) {
                return true;
            }
        }
        
        // Check for known malicious IP patterns
        if ($this->isKnownMaliciousIP($ip)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Check if IP matches known malicious patterns
     */
    private function isKnownMaliciousIP($ip) {
        // Check for common malicious IP patterns
        $maliciousPatterns = array(
            '/^0\.0\.0\.0$/',           // Invalid IP
            '/^127\.0\.0\.1$/',         // Localhost (suspicious for external connections)
            '/^192\.168\./',            // Private network (suspicious for external)
            '/^10\./',                  // Private network
            '/^172\.(1[6-9]|2[0-9]|3[01])\./', // Private network
        );
        
        foreach ($maliciousPatterns as $pattern) {
            if (preg_match($pattern, $ip)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if this is a brute force attempt
     */
    private function isBruteForceAttempt($ip) {
        if (!isset($this->suspiciousActivity[$ip])) {
            $this->suspiciousActivity[$ip] = array(
                'login_attempts' => 0,
                'last_attempt' => 0,
                'blocked_until' => 0
            );
        }
        
        $activity = &$this->suspiciousActivity[$ip];
        $currentTime = time();
        
        // Check if IP is currently blocked
        if ($activity['blocked_until'] > $currentTime) {
            return true;
        }
        
        // Reset counter if enough time has passed
        if (($currentTime - $activity['last_attempt']) > self::BRUTE_FORCE_TIMEOUT) {
            $activity['login_attempts'] = 0;
        }
        
        $activity['login_attempts']++;
        $activity['last_attempt'] = $currentTime;
        
        // Block if too many attempts
        if ($activity['login_attempts'] > self::MAX_LOGIN_ATTEMPTS) {
            $activity['blocked_until'] = $currentTime + self::BRUTE_FORCE_TIMEOUT;
            return true;
        }
        
        return false;
    }
    
    /**
     * Validate username format
     */
    private function isValidUsername($username) {
        // Check length
        if (strlen($username) < 3 || strlen($username) > 16) {
            return false;
        }
        
        // Check for valid characters (alphanumeric and underscore only)
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            return false;
        }
        
        // Check for reserved names
        $reservedNames = array('admin', 'administrator', 'root', 'system', 'server', 'console');
        if (in_array(strtolower($username), $reservedNames)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Sanitize input to prevent injection attacks
     */
    private function sanitizeInput($input) {
        // Remove null bytes
        $input = str_replace("\0", "", $input);
        
        // Remove control characters except newline and tab
        $input = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $input);
        
        // Trim whitespace
        $input = trim($input);
        
        return $input;
    }
    
    /**
     * Check if command is potentially dangerous
     */
    private function isDangerousCommand($command) {
        $dangerousCommands = array(
            'eval', 'exec', 'system', 'shell_exec', 'passthru',
            'file_get_contents', 'file_put_contents', 'fopen', 'fwrite',
            'include', 'require', 'include_once', 'require_once',
            'unlink', 'rmdir', 'chmod', 'chown'
        );
        
        $commandLower = strtolower($command);
        
        foreach ($dangerousCommands as $dangerous) {
            if (strpos($commandLower, $dangerous) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if command is administrative
     */
    private function isAdminCommand($command) {
        $adminCommands = array(
            'ban', 'unban', 'kick', 'op', 'deop', 'whitelist',
            'stop', 'restart', 'reload', 'save-all', 'gamemode'
        );
        
        $commandParts = explode(' ', strtolower($command));
        $baseCommand = $commandParts[0];
        
        return in_array($baseCommand, $adminCommands);
    }
    
    /**
     * Clean up old connection data
     */
    public function cleanupConnections() {
        $currentTime = time();
        
        // Clean up connection attempts
        foreach ($this->connectionAttempts as $ip => $attempts) {
            $this->connectionAttempts[$ip] = array_filter(
                $attempts,
                function($timestamp) use ($currentTime) {
                    return ($currentTime - $timestamp) < self::CONNECTION_TIMEOUT;
                }
            );
            
            if (empty($this->connectionAttempts[$ip])) {
                unset($this->connectionAttempts[$ip]);
            }
        }
        
        // Clean up suspicious activity records
        foreach ($this->suspiciousActivity as $ip => $activity) {
            if (($currentTime - $activity['last_attempt']) > self::BRUTE_FORCE_TIMEOUT * 2) {
                unset($this->suspiciousActivity[$ip]);
            }
        }
    }
    
    /**
     * Ban an IP address
     */
    public function banIP($ip, $reason = "Security violation") {
        $this->bannedIPs[$ip] = true;
        
        // Add to banned IPs file
        $banFile = DATA_PATH . "banned-ips.txt";
        $entry = $ip . " # " . $reason . " - " . date('Y-m-d H:i:s') . "\n";
        file_put_contents($banFile, $entry, FILE_APPEND | LOCK_EX);
        
        console("[SECURITY] IP banned: " . $ip . " (" . $reason . ")");
    }
    
    /**
     * Unban an IP address
     */
    public function unbanIP($ip) {
        unset($this->bannedIPs[$ip]);
        
        // Remove from banned IPs file
        $banFile = DATA_PATH . "banned-ips.txt";
        if (file_exists($banFile)) {
            $lines = file($banFile, FILE_IGNORE_NEW_LINES);
            $newLines = array();
            
            foreach ($lines as $line) {
                if (strpos(trim($line), $ip) !== 0) {
                    $newLines[] = $line;
                }
            }
            
            file_put_contents($banFile, implode("\n", $newLines) . "\n");
        }
        
        console("[SECURITY] IP unbanned: " . $ip);
    }
    
    /**
     * Get security statistics
     */
    public function getSecurityStats() {
        return array(
            'banned_ips' => count($this->bannedIPs),
            'active_connections' => count($this->connectionAttempts),
            'suspicious_ips' => count($this->suspiciousActivity)
        );
    }
}
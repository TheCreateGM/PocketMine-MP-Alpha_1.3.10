<?php

/**
 * Basic Mob AI System for PocketMine-MP Alpha 1.3.10
 * 
 * Provides basic AI behaviors for mobs:
 * - Hostile mob targeting and pathfinding
 * - Passive mob wandering and fleeing
 * - Line of sight detection
 * - Basic attack mechanics
 * 
 * @author AxoGM
 */

class MobAI {
    private $server;
    private $mobStates = array();
    private $mobTargets = array();
    private $mobPaths = array();
    
    // AI Configuration
    const SIGHT_RANGE = 16.0; // blocks
    const ATTACK_RANGE = 2.0; // blocks
    const FLEE_RANGE = 8.0; // blocks
    const WANDER_RANGE = 8.0; // blocks
    const AI_UPDATE_INTERVAL = 40; // ticks (2 seconds) - reduced frequency for smoother movement
    const PATHFIND_INTERVAL = 80; // ticks (4 seconds)
    
    // Mob states
    const STATE_IDLE = 0;
    const STATE_WANDERING = 1;
    const STATE_TARGETING = 2;
    const STATE_ATTACKING = 3;
    const STATE_FLEEING = 4;
    
    // Movement speeds (blocks per movement) - vanilla-like speeds
    const SPEED_WALK = 1.0;   // 1 block per movement
    const SPEED_RUN = 1.5;    // 1.5 blocks per movement  
    const SPEED_FLEE = 2.0;   // 2 blocks per movement
    
    public function __construct() {
        $this->server = ServerAPI::request();
        $this->initializeAI();
    }
    
    private function initializeAI() {
        // Schedule AI updates more frequently
        $this->server->schedule(self::AI_UPDATE_INTERVAL, array($this, "updateMobAI"), array(), true);
        
        // Register event handlers
        $this->server->addHandler("entity.spawn", array($this, "initializeMob"), 1);
        $this->server->addHandler("entity.death", array($this, "cleanupMob"), 1);
        $this->server->addHandler("entity.damage", array($this, "handleMobDamage"), 1);
        
        // Initialize AI for existing mobs
        $this->initializeExistingMobs();
        
        console("[MOB-AI] Mob AI system initialized");
    }
    
    /**
     * Initialize AI for existing mobs in all levels
     */
    private function initializeExistingMobs() {
        $initialized = 0;
        
        // Get all levels - try different API methods
        $levels = array();
        
        if (method_exists($this->server->api->level, 'getAll')) {
            $levels = $this->server->api->level->getAll();
        } elseif (isset($this->server->levels)) {
            $levels = $this->server->levels;
        } elseif (method_exists($this->server, 'getLevels')) {
            $levels = $this->server->getLevels();
        }
        
        foreach ($levels as $level) {
            if (!is_object($level)) {
                continue;
            }
            
            $entities = $this->server->api->entity->getAll($level);
            
            foreach ($entities as $entity) {
                if ($entity->class === ENTITY_MOB && !isset($this->mobStates[$entity->eid])) {
                    $this->mobStates[$entity->eid] = array(
                        'state' => self::STATE_IDLE,
                        'lastUpdate' => 0,
                        'lastPathfind' => 0,
                        'wanderTarget' => null,
                        'stateTimer' => 0,
                        'lastPosition' => array('x' => $entity->x, 'y' => $entity->y, 'z' => $entity->z),
                        'lastMoveTime' => 0
                    );
                    $initialized++;
                }
            }
        }
        
        if ($initialized > 0) {
            console("[MOB-AI] Initialized AI for " . $initialized . " existing mobs");
        }
    }
    
    /**
     * Initialize AI state for a new mob
     */
    public function initializeMob($data) {
        if (!isset($data['entity']) || !($data['entity'] instanceof Entity)) {
            return;
        }
        
        $entity = $data['entity'];
        
        if ($entity->class !== ENTITY_MOB) {
            return;
        }
        
        $this->mobStates[$entity->eid] = array(
            'state' => self::STATE_IDLE,
            'lastUpdate' => 0,
            'lastPathfind' => 0,
            'wanderTarget' => null,
            'stateTimer' => 0,
            'lastPosition' => array('x' => $entity->x, 'y' => $entity->y, 'z' => $entity->z),
            'lastMoveTime' => 0
        );
        
        console("[MOB-AI] Initialized AI for mob EID: " . $entity->eid . " (Type: " . $entity->type . ")");
    }
    
    /**
     * Clean up AI state when mob dies
     */
    public function cleanupMob($data) {
        if (!isset($data['entity']) || !($data['entity'] instanceof Entity)) {
            return;
        }
        
        $entity = $data['entity'];
        
        if (isset($this->mobStates[$entity->eid])) {
            unset($this->mobStates[$entity->eid]);
            unset($this->mobTargets[$entity->eid]);
            unset($this->mobPaths[$entity->eid]);
        }
    }
    
    /**
     * Handle mob taking damage - triggers flee behavior for passive mobs
     */
    public function handleMobDamage($data) {
        if (!isset($data['entity']) || !($data['entity'] instanceof Entity)) {
            return;
        }
        
        $entity = $data['entity'];
        
        if ($entity->class !== ENTITY_MOB || !isset($this->mobStates[$entity->eid])) {
            return;
        }
        
        // If it's a passive mob and was damaged by a player, make it flee
        if ($this->isPassiveMob($entity->type) && isset($data['source'])) {
            $source = $data['source'];
            
            if ($source instanceof Player) {
                $this->setMobState($entity->eid, self::STATE_FLEEING);
                $this->mobTargets[$entity->eid] = $source;
                
                console("[MOB-AI] Passive mob " . $entity->eid . " fleeing from player " . $source->username);
            }
        }
    }
    
    /**
     * Main AI update loop
     */
    public function updateMobAI() {
        foreach ($this->mobStates as $mobEID => $state) {
            $mob = $this->server->api->entity->get($mobEID);
            
            if (!($mob instanceof Entity) || $mob->class !== ENTITY_MOB) {
                // Mob no longer exists
                unset($this->mobStates[$mobEID]);
                unset($this->mobTargets[$mobEID]);
                unset($this->mobPaths[$mobEID]);
                continue;
            }
            
            $this->updateMobBehavior($mob);
        }
    }
    
    /**
     * Update behavior for a specific mob
     */
    private function updateMobBehavior($mob) {
        $mobEID = $mob->eid;
        $state = $this->mobStates[$mobEID];
        
        // Increment state timer
        $this->mobStates[$mobEID]['stateTimer']++;
        
        if ($this->isHostileMob($mob->type)) {
            $this->updateHostileMobBehavior($mob);
        } else {
            $this->updatePassiveMobBehavior($mob);
        }
    }
    
    /**
     * Update behavior for hostile mobs
     */
    private function updateHostileMobBehavior($mob) {
        $mobEID = $mob->eid;
        $state = $this->mobStates[$mobEID];
        
        // Look for nearby players to target
        $nearestPlayer = $this->findNearestPlayer($mob);
        
        switch ($state['state']) {
            case self::STATE_IDLE:
            case self::STATE_WANDERING:
                if ($nearestPlayer !== null && $this->canSeeTarget($mob, $nearestPlayer)) {
                    // Found a target, switch to targeting mode
                    $this->setMobState($mobEID, self::STATE_TARGETING);
                    $this->mobTargets[$mobEID] = $nearestPlayer;
                    console("[MOB-AI] Hostile mob " . $mobEID . " targeting player " . $nearestPlayer->username);
                } else {
                    // No target, wander around
                    $this->handleWandering($mob);
                }
                break;
                
            case self::STATE_TARGETING:
                $target = isset($this->mobTargets[$mobEID]) ? $this->mobTargets[$mobEID] : null;
                
                if ($target === null || !($target instanceof Player) || !$target->spawned) {
                    // Target lost, go back to idle
                    $this->setMobState($mobEID, self::STATE_IDLE);
                    unset($this->mobTargets[$mobEID]);
                    break;
                }
                
                $distance = $this->calculateDistance($mob, $target->entity);
                
                if ($distance > self::SIGHT_RANGE) {
                    // Target too far, lose target
                    $this->setMobState($mobEID, self::STATE_IDLE);
                    unset($this->mobTargets[$mobEID]);
                } elseif ($distance <= self::ATTACK_RANGE) {
                    // Close enough to attack
                    $this->setMobState($mobEID, self::STATE_ATTACKING);
                } else {
                    // Move towards target
                    $this->moveTowardsTarget($mob, $target->entity, self::SPEED_RUN);
                }
                break;
                
            case self::STATE_ATTACKING:
                $target = isset($this->mobTargets[$mobEID]) ? $this->mobTargets[$mobEID] : null;
                
                if ($target === null || !($target instanceof Player) || !$target->spawned) {
                    $this->setMobState($mobEID, self::STATE_IDLE);
                    unset($this->mobTargets[$mobEID]);
                    break;
                }
                
                $distance = $this->calculateDistance($mob, $target->entity);
                
                if ($distance > self::ATTACK_RANGE) {
                    // Target moved away, go back to targeting
                    $this->setMobState($mobEID, self::STATE_TARGETING);
                } else {
                    // Attack the target
                    $this->attackTarget($mob, $target);
                }
                break;
        }
    }
    
    /**
     * Update behavior for passive mobs
     */
    private function updatePassiveMobBehavior($mob) {
        $mobEID = $mob->eid;
        $state = $this->mobStates[$mobEID];
        
        switch ($state['state']) {
            case self::STATE_IDLE:
                // Less frequent wandering for smoother gameplay
                if (mt_rand(1, 100) <= 10) { // 10% chance per update (2 second intervals)
                    $this->setMobState($mobEID, self::STATE_WANDERING);
                }
                break;
                
            case self::STATE_WANDERING:
                $this->handleWandering($mob);
                
                // Wander for much longer periods to reduce state changes
                if ($state['stateTimer'] > 5) { // ~10 seconds at 2-second intervals
                    // 50% chance to continue wandering, 50% to go idle
                    if (mt_rand(1, 100) <= 50) {
                        $this->setMobState($mobEID, self::STATE_IDLE);
                    }
                }
                break;
                
            case self::STATE_FLEEING:
                $threat = isset($this->mobTargets[$mobEID]) ? $this->mobTargets[$mobEID] : null;
                
                if ($threat === null || !($threat instanceof Player)) {
                    $this->setMobState($mobEID, self::STATE_IDLE);
                    unset($this->mobTargets[$mobEID]);
                    break;
                }
                
                $distance = $this->calculateDistance($mob, $threat->entity);
                
                if ($distance > self::FLEE_RANGE || $state['stateTimer'] > 200) { // ~10 seconds max flee
                    // Safe distance reached or flee timeout
                    $this->setMobState($mobEID, self::STATE_IDLE);
                    unset($this->mobTargets[$mobEID]);
                } else {
                    // Move away from threat
                    $this->moveAwayFromTarget($mob, $threat->entity, self::SPEED_FLEE);
                }
                break;
        }
    }
    
    /**
     * Handle wandering behavior
     */
    private function handleWandering($mob) {
        $mobEID = $mob->eid;
        $state = $this->mobStates[$mobEID];
        
        // Generate new wander target if needed
        if ($state['wanderTarget'] === null || $this->hasReachedTarget($mob, $state['wanderTarget'])) {
            $this->mobStates[$mobEID]['wanderTarget'] = $this->generateWanderTarget($mob);
        }
        
        if ($state['wanderTarget'] !== null) {
            $this->moveTowardsPosition($mob, $state['wanderTarget'], self::SPEED_WALK);
        }
    }
    
    /**
     * Generate a random wander target around the mob - vanilla-like behavior
     */
    private function generateWanderTarget($mob) {
        $attempts = 0;
        $maxAttempts = 8;
        
        while ($attempts < $maxAttempts) {
            // Generate more natural movement patterns
            $angle = mt_rand(0, 360) * (M_PI / 180);
            $distance = mt_rand(2, 5); // Shorter distances for more natural movement
            
            $targetX = $mob->x + cos($angle) * $distance;
            $targetZ = $mob->z + sin($angle) * $distance;
            $targetY = $this->findGroundLevel($targetX, $targetZ, $mob->level);
            
            if ($targetY !== null) {
                // Check if the target is not too far from spawn area (prevent mobs from wandering too far)
                $distanceFromSpawn = sqrt(pow($targetX - $mob->x, 2) + pow($targetZ - $mob->z, 2));
                if ($distanceFromSpawn <= self::WANDER_RANGE) {
                    return array('x' => $targetX, 'y' => $targetY + 1, 'z' => $targetZ);
                }
            }
            
            $attempts++;
        }
        
        // Fallback: stay in place if no valid target found
        return null;
    }
    
    /**
     * Find the nearest player to a mob
     */
    private function findNearestPlayer($mob) {
        $nearestPlayer = null;
        $nearestDistance = self::SIGHT_RANGE;
        
        $players = $this->server->api->player->getAll($mob->level);
        
        foreach ($players as $player) {
            if (!($player instanceof Player) || !($player->entity instanceof Entity)) {
                continue;
            }
            
            $distance = $this->calculateDistance($mob, $player->entity);
            
            if ($distance < $nearestDistance) {
                $nearestDistance = $distance;
                $nearestPlayer = $player;
            }
        }
        
        return $nearestPlayer;
    }
    
    /**
     * Check if mob can see target (simple line of sight)
     */
    private function canSeeTarget($mob, $target) {
        // Simple implementation - just check if target is within sight range
        // In a more advanced implementation, you would do raycast for obstacles
        $distance = $this->calculateDistance($mob, $target->entity);
        return $distance <= self::SIGHT_RANGE;
    }
    
    /**
     * Move mob towards a target entity
     */
    private function moveTowardsTarget($mob, $target, $speed) {
        $direction = $this->calculateDirection($mob, $target);
        $this->moveMob($mob, $direction, $speed);
    }
    
    /**
     * Move mob away from a target entity
     */
    private function moveAwayFromTarget($mob, $target, $speed) {
        $direction = $this->calculateDirection($mob, $target);
        // Reverse direction to move away
        $direction['x'] *= -1;
        $direction['z'] *= -1;
        $this->moveMob($mob, $direction, $speed);
    }
    
    /**
     * Move mob towards a specific position
     */
    private function moveTowardsPosition($mob, $targetPos, $speed) {
        $direction = array(
            'x' => $targetPos['x'] - $mob->x,
            'y' => $targetPos['y'] - $mob->y,
            'z' => $targetPos['z'] - $mob->z
        );
        
        // Normalize direction
        $length = sqrt($direction['x'] * $direction['x'] + $direction['z'] * $direction['z']);
        if ($length > 0) {
            $direction['x'] /= $length;
            $direction['z'] /= $length;
        }
        
        $this->moveMob($mob, $direction, $speed);
    }
    
    /**
     * Actually move the mob - vanilla-like smooth movement
     */
    private function moveMob($mob, $direction, $speed) {
        // Check if mob moved recently to prevent spam
        $mobEID = $mob->eid;
        if (isset($this->mobStates[$mobEID]['lastMoveTime'])) {
            $timeSinceLastMove = time() - $this->mobStates[$mobEID]['lastMoveTime'];
            if ($timeSinceLastMove < 1) { // Minimum 1 second between moves
                return;
            }
        }
        
        $newX = $mob->x + $direction['x'] * $speed;
        $newZ = $mob->z + $direction['z'] * $speed;
        $newY = $this->findGroundLevel($newX, $newZ, $mob->level);
        
        if ($newY === null) {
            return; // Can't move there
        }
        
        // Check if the movement is significant enough (prevent micro-movements)
        $moveDistance = sqrt(pow($newX - $mob->x, 2) + pow($newZ - $mob->z, 2));
        if ($moveDistance < 0.5) {
            return; // Movement too small, skip
        }
        
        // Store old position
        $oldX = $mob->x;
        $oldY = $mob->y;
        $oldZ = $mob->z;
        
        // Calculate yaw (rotation) to face movement direction with proper normalization
        $yaw = atan2($direction['z'], $direction['x']) * (180 / M_PI) - 90;
        
        // Normalize yaw to 0-360 range to prevent precision errors
        $yaw = fmod($yaw, 360);
        if ($yaw < 0) {
            $yaw += 360;
        }
        
        // Ensure yaw is within reasonable bounds (0-360)
        $yaw = max(0, min(360, $yaw));
        
        // Update mob position smoothly with bounds checking
        $mob->x = max(-30000000, min(30000000, $newX)); // Prevent extreme coordinates
        $mob->y = max(0, min(256, $newY + 1)); // Keep within world height limits
        $mob->z = max(-30000000, min(30000000, $newZ)); // Prevent extreme coordinates
        $mob->yaw = $yaw;
        
        // Send proper movement packets to all players (Bedrock-style movement)
        $players = $this->server->api->player->getAll($mob->level);
        foreach ($players as $player) {
            if ($player instanceof Player && $player->spawned) {
                // Send move entity packet (this is how Bedrock handles mob movement)
                $player->dataPacket(MC_MOVE_ENTITY_POSROT, array(
                    "eid" => $mob->eid,
                    "x" => $mob->x,
                    "y" => $mob->y,
                    "z" => $mob->z,
                    "yaw" => $mob->yaw,
                    "pitch" => 0
                ));
            }
        }
        
        // Update last position and move time for AI tracking
        if (isset($this->mobStates[$mobEID])) {
            $this->mobStates[$mobEID]['lastPosition'] = array(
                'x' => $oldX,
                'y' => $oldY,
                'z' => $oldZ
            );
            $this->mobStates[$mobEID]['lastMoveTime'] = time();
        }
        
        // Debug log for movement (remove in production)
        // console("[MOB-AI] Moved mob " . $mobEID . " from (" . round($oldX, 1) . ", " . round($oldZ, 1) . ") to (" . round($newX, 1) . ", " . round($newZ, 1) . ")");
    }
    
    /**
     * Attack a target
     */
    private function attackTarget($mob, $target) {
        $mobEID = $mob->eid;
        $state = $this->mobStates[$mobEID];
        
        // Limit attack rate
        if ($state['stateTimer'] < 20) { // 1 second between attacks
            return;
        }
        
        // Reset attack timer
        $this->mobStates[$mobEID]['stateTimer'] = 0;
        
        // Calculate damage based on mob type
        $damage = $this->getMobAttackDamage($mob->type);
        
        // Deal damage to target
        $target->entity->harm($damage, $mob->eid);
        
        // Send attack animation
        $this->server->api->entity->broadcastPacket(
            $this->server->api->player->getAll($mob->level),
            MC_ANIMATE,
            array(
                "eid" => $mob->eid,
                "action" => 1 // Swing arm
            )
        );
        
        console("[MOB-AI] Mob " . $mobEID . " attacked " . $target->username . " for " . $damage . " damage");
    }
    
    /**
     * Get attack damage for mob type
     */
    private function getMobAttackDamage($mobType) {
        $damages = array(
            MOB_ZOMBIE => 3,
            MOB_SKELETON => 2,
            MOB_CREEPER => 0, // Creepers explode instead
            MOB_SPIDER => 2
        );
        
        return isset($damages[$mobType]) ? $damages[$mobType] : 1;
    }
    
    /**
     * Calculate direction vector from mob to target
     */
    private function calculateDirection($mob, $target) {
        $direction = array(
            'x' => $target->x - $mob->x,
            'y' => $target->y - $mob->y,
            'z' => $target->z - $mob->z
        );
        
        // Normalize horizontal direction
        $length = sqrt($direction['x'] * $direction['x'] + $direction['z'] * $direction['z']);
        if ($length > 0) {
            $direction['x'] /= $length;
            $direction['z'] /= $length;
        }
        
        return $direction;
    }
    
    /**
     * Calculate distance between two entities
     */
    private function calculateDistance($entity1, $entity2) {
        return sqrt(
            pow($entity2->x - $entity1->x, 2) +
            pow($entity2->y - $entity1->y, 2) +
            pow($entity2->z - $entity1->z, 2)
        );
    }
    
    /**
     * Check if mob has reached its target position
     */
    private function hasReachedTarget($mob, $target) {
        $distance = sqrt(
            pow($target['x'] - $mob->x, 2) +
            pow($target['z'] - $mob->z, 2)
        );
        
        return $distance < 1.5; // Within 1.5 blocks
    }
    
    /**
     * Find ground level at coordinates
     */
    private function findGroundLevel($x, $z, $level) {
        $blockX = floor($x);
        $blockZ = floor($z);
        
        for ($y = 127; $y >= 1; $y--) {
            $blockData = $level->level->getBlock($blockX, $y, $blockZ);
            $blockId = $blockData[0];
            $blockAboveData = $level->level->getBlock($blockX, $y + 1, $blockZ);
            $blockAbove = $blockAboveData[0];
            
            if ($this->isSolidBlock($blockId) && $blockAbove === AIR) {
                return $y;
            }
        }
        
        return null;
    }
    
    /**
     * Check if block is solid
     */
    private function isSolidBlock($blockId) {
        $solidBlocks = array(
            GRASS, DIRT, STONE, COBBLESTONE, SAND, GRAVEL,
            WOOD, PLANKS, LEAVES, SANDSTONE, CLAY_BLOCK
        );
        
        return in_array($blockId, $solidBlocks);
    }
    
    /**
     * Set mob state
     */
    private function setMobState($mobEID, $newState) {
        if (isset($this->mobStates[$mobEID])) {
            $this->mobStates[$mobEID]['state'] = $newState;
            $this->mobStates[$mobEID]['stateTimer'] = 0;
            
            // Clear wander target when changing states
            if ($newState !== self::STATE_WANDERING) {
                $this->mobStates[$mobEID]['wanderTarget'] = null;
            }
        }
    }
    
    /**
     * Check if mob type is hostile
     */
    private function isHostileMob($mobType) {
        $hostileMobs = array(MOB_ZOMBIE, MOB_SKELETON, MOB_CREEPER, MOB_SPIDER);
        return in_array($mobType, $hostileMobs);
    }
    
    /**
     * Check if mob type is passive
     */
    private function isPassiveMob($mobType) {
        $passiveMobs = array(MOB_PIG, MOB_COW, MOB_SHEEP, MOB_CHICKEN);
        return in_array($mobType, $passiveMobs);
    }
    
    /**
     * Get AI statistics
     */
    public function getAIStats() {
        $stats = array(
            'total_mobs' => count($this->mobStates),
            'states' => array(
                'idle' => 0,
                'wandering' => 0,
                'targeting' => 0,
                'attacking' => 0,
                'fleeing' => 0
            )
        );
        
        foreach ($this->mobStates as $state) {
            switch ($state['state']) {
                case self::STATE_IDLE:
                    $stats['states']['idle']++;
                    break;
                case self::STATE_WANDERING:
                    $stats['states']['wandering']++;
                    break;
                case self::STATE_TARGETING:
                    $stats['states']['targeting']++;
                    break;
                case self::STATE_ATTACKING:
                    $stats['states']['attacking']++;
                    break;
                case self::STATE_FLEEING:
                    $stats['states']['fleeing']++;
                    break;
            }
        }
        
        return $stats;
    }
    
    /**
     * Wake up nearby mobs and force them to start wandering
     */
    public function wakeUpNearbyMobs($player) {
        $wokenMobs = 0;
        $playerPos = array(
            'x' => $player->entity->x,
            'y' => $player->entity->y,
            'z' => $player->entity->z
        );
        
        foreach ($this->mobStates as $mobEID => $state) {
            $mob = $this->server->api->entity->get($mobEID);
            
            if (!($mob instanceof Entity) || $mob->class !== ENTITY_MOB) {
                continue;
            }
            
            if ($mob->level !== $player->level) {
                continue;
            }
            
            $distance = $this->calculateDistance($mob, $player->entity);
            
            if ($distance <= 50) { // Within 50 blocks
                // Force mob to start wandering
                $this->setMobState($mobEID, self::STATE_WANDERING);
                $wokenMobs++;
                
                console("[MOB-AI] Woke up mob EID: " . $mobEID . " (Distance: " . round($distance, 1) . ")");
            }
        }
        
        return $wokenMobs;
    }
}
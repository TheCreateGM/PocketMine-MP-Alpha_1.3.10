<?php

/**
 * PHP Compatibility Layer for PocketMine-MP Alpha 1.3.10
 * 
 * Provides compatibility functions for modern PHP features
 * when running on older PHP versions (5.x/7.x)
 * 
 * @author AxoGM
 */

// str_starts_with compatibility (PHP 8.0+)
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

// str_ends_with compatibility (PHP 8.0+)
if (!function_exists('str_ends_with')) {
    function str_ends_with($haystack, $needle) {
        return $needle === '' || substr($haystack, -strlen($needle)) === $needle;
    }
}

// str_contains compatibility (PHP 8.0+)
if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) {
        return strpos($haystack, $needle) !== false;
    }
}

// array_key_first compatibility (PHP 7.3+)
if (!function_exists('array_key_first')) {
    function array_key_first($array) {
        foreach ($array as $key => $value) {
            return $key;
        }
        return null;
    }
}

// array_key_last compatibility (PHP 7.3+)
if (!function_exists('array_key_last')) {
    function array_key_last($array) {
        return array_key_first(array_reverse($array, true));
    }
}

// is_countable compatibility (PHP 7.3+)
if (!function_exists('is_countable')) {
    function is_countable($value) {
        return is_array($value) || $value instanceof Countable;
    }
}

/**
 * Enhanced error handling for older PHP versions
 */
class EnhancedErrorHandler {
    
    /**
     * Convert PHP errors to exceptions for better error handling
     */
    public static function handleError($severity, $message, $file, $line) {
        if (!(error_reporting() & $severity)) {
            return false;
        }
        
        // Don't convert deprecation warnings to exceptions for legacy code compatibility
        if ($severity === E_DEPRECATED || $severity === E_USER_DEPRECATED) {
            console("[DEPRECATED] " . $message . " in " . $file . " on line " . $line);
            return true;
        }
        
        // Don't convert strict standards notices to exceptions
        if (defined('E_STRICT') && $severity === E_STRICT) {
            console("[STRICT] " . $message . " in " . $file . " on line " . $line);
            return true;
        }
        
        // Only convert actual errors to exceptions
        if ($severity & (E_ERROR | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR)) {
            throw new ErrorException($message, 0, $severity, $file, $line);
        }
        
        // Log other errors but don't throw exceptions
        console("[ERROR] " . $message . " in " . $file . " on line " . $line);
        return true;
    }
    
    /**
     * Handle uncaught exceptions
     */
    public static function handleException($exception) {
        console("[FATAL ERROR] Uncaught exception: " . $exception->getMessage() . 
                " in " . $exception->getFile() . " on line " . $exception->getLine());
        
        // Log stack trace
        console("[STACK TRACE] " . $exception->getTraceAsString());
    }
    
    /**
     * Initialize enhanced error handling
     */
    public static function initialize() {
        set_error_handler(array('EnhancedErrorHandler', 'handleError'));
        set_exception_handler(array('EnhancedErrorHandler', 'handleException'));
    }
}

/**
 * Modern array functions for older PHP versions
 */
class ModernArrayUtils {
    
    /**
     * array_filter with ARRAY_FILTER_USE_KEY flag compatibility
     */
    public static function array_filter_key($array, $callback) {
        $result = array();
        foreach ($array as $key => $value) {
            if ($callback($key)) {
                $result[$key] = $value;
            }
        }
        return $result;
    }
    
    /**
     * array_filter with ARRAY_FILTER_USE_BOTH flag compatibility
     */
    public static function array_filter_both($array, $callback) {
        $result = array();
        foreach ($array as $key => $value) {
            if ($callback($value, $key)) {
                $result[$key] = $value;
            }
        }
        return $result;
    }
    
    /**
     * array_column compatibility for older PHP versions
     */
    public static function array_column_compat($array, $column_key, $index_key = null) {
        if (function_exists('array_column')) {
            return array_column($array, $column_key, $index_key);
        }
        
        $result = array();
        foreach ($array as $row) {
            $value = is_array($row) ? $row[$column_key] : $row->$column_key;
            
            if ($index_key !== null) {
                $key = is_array($row) ? $row[$index_key] : $row->$index_key;
                $result[$key] = $value;
            } else {
                $result[] = $value;
            }
        }
        
        return $result;
    }
}

/**
 * JSON handling improvements
 */
class EnhancedJSON {
    
    /**
     * Safe JSON decode with error handling
     */
    public static function decode($json, $assoc = false, $depth = 512, $flags = 0) {
        $result = json_decode($json, $assoc, $depth, $flags);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException('JSON decode error: ' . json_last_error_msg());
        }
        
        return $result;
    }
    
    /**
     * Safe JSON encode with error handling
     */
    public static function encode($value, $flags = 0, $depth = 512) {
        $result = json_encode($value, $flags, $depth);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException('JSON encode error: ' . json_last_error_msg());
        }
        
        return $result;
    }
}

/**
 * String utilities for older PHP versions
 */
class ModernStringUtils {
    
    /**
     * mb_str_split compatibility
     */
    public static function mb_str_split($string, $length = 1, $encoding = 'UTF-8') {
        if (function_exists('mb_str_split')) {
            return mb_str_split($string, $length, $encoding);
        }
        
        $result = array();
        $strlen = mb_strlen($string, $encoding);
        
        for ($i = 0; $i < $strlen; $i += $length) {
            $result[] = mb_substr($string, $i, $length, $encoding);
        }
        
        return $result;
    }
    
    /**
     * Safe string truncation with UTF-8 support
     */
    public static function truncate($string, $length, $suffix = '...', $encoding = 'UTF-8') {
        if (mb_strlen($string, $encoding) <= $length) {
            return $string;
        }
        
        return mb_substr($string, 0, $length - mb_strlen($suffix, $encoding), $encoding) . $suffix;
    }
    
    /**
     * Generate random string with specified length and character set
     */
    public static function randomString($length, $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') {
        $result = '';
        $charsLength = strlen($chars);
        
        for ($i = 0; $i < $length; $i++) {
            $result .= $chars[mt_rand(0, $charsLength - 1)];
        }
        
        return $result;
    }
}

/**
 * File system utilities
 */
class ModernFileUtils {
    
    /**
     * Safe file operations with atomic writes
     */
    public static function writeFileAtomic($filename, $data, $flags = 0) {
        $tempFile = $filename . '.tmp.' . uniqid();
        
        if (file_put_contents($tempFile, $data, $flags) === false) {
            return false;
        }
        
        if (!rename($tempFile, $filename)) {
            unlink($tempFile);
            return false;
        }
        
        return true;
    }
    
    /**
     * Safe directory creation with proper permissions
     */
    public static function createDirectory($path, $permissions = 0755, $recursive = true) {
        if (is_dir($path)) {
            return true;
        }
        
        return mkdir($path, $permissions, $recursive);
    }
    
    /**
     * Get file size in human readable format
     */
    public static function formatFileSize($bytes, $precision = 2) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }
}

/**
 * Safe ord() function that handles null values
 */
if (!function_exists('safe_ord')) {
    function safe_ord($character) {
        if ($character === null || $character === '') {
            return 0;
        }
        return ord($character);
    }
}

/**
 * Safe chr() function that handles invalid values
 */
if (!function_exists('safe_chr')) {
    function safe_chr($ascii) {
        if ($ascii < 0 || $ascii > 255) {
            return "\0";
        }
        return chr($ascii);
    }
}

// Enhanced error handling is available but not automatically initialized
// to avoid conflicts with existing PocketMine-MP error handling
// Call EnhancedErrorHandler::initialize() manually if needed
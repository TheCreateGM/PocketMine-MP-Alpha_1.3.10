<?php

/**
 *
 *  ____            _        _   __  __ _                  __  __ ____  
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \ 
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/ 
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_| 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 * 
 *
*/

define("ASYNC_CURL_GET", 1);
define("ASYNC_CURL_POST", 2);

class StackableArray{
	public $counter = 0;
	public function run(){}
}

// Remove or disable AsyncMultipleQueue and Async classes that extend Thread for PHP 7/8 compatibility
// class AsyncMultipleQueue extends Thread { ... }
// class Async extends Thread { ... }
// Instead, provide stub or fallback implementations:
class AsyncMultipleQueue {
    public $input;
    public $output;
    public $stop;
    public function __construct() {
        $this->input = "";
        $this->output = "";
        $this->stop = false;
    }
    // No threading, just stubs
    private function get($len) { return ""; }
    public function run() {}
}

class Async {
    public $method;
    public $params;
    public $result;
    public $joined;
    public function __construct($method, $params = array()) {
        $this->method = $method;
        $this->params = $params;
        $this->result = null;
        $this->joined = false;
    }
    public function run() {
        $this->result = call_user_func_array($this->method, $this->params);
        return $this->result !== null;
    }
    public static function call($method, $params = array()) {
        $async = new Async($method, $params);
        $async->run();
        return $async;
    }
    public function __toString() {
        if(!$this->joined) {
            $this->joined = true;
        }
        return (string)$this->result;
    }
}
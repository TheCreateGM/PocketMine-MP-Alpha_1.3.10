<?php

/**
 *
 *  ____            _        _   __  __ _                  __  __ ____  
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \ 
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/ 
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_| 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 * 
 *
*/

class ChatAPI{
	private $server;
	function __construct(){
		$this->server = ServerAPI::request();
	}
	
	public function init(){
		$this->server->api->console->register("tell", "<player> <private message ...>", array($this, "commandHandler"));
		$this->server->api->console->register("me", "<action ...>", array($this, "commandHandler"));
		$this->server->api->console->register("say", "<message ...>", array($this, "commandHandler"));
		$this->server->api->ban->cmdWhitelist("tell");
		$this->server->api->ban->cmdWhitelist("me");
	}
	
	public function commandHandler($cmd, $params, $issuer, $alias){
		$output = "";
		switch($cmd){
			case "say":
				// Ensure params is properly handled as an array
				$paramsArray = is_array($params) ? $params : array();
				$s = implode(" ", $paramsArray);
				if(trim($s) == ""){
					$output .= "Usage: /say <message>\n";
					break;
				}
				$sender = ($issuer instanceof Player) ? "Server":ucfirst($issuer);
				$broadcastMessage = "[$sender] ".$s;
				$this->server->api->chat->broadcast($broadcastMessage);
				break;
			case "me":
				if(!($issuer instanceof Player)){
					if($issuer === "rcon"){
						$sender = "Rcon";
					}else{
						$sender = ucfirst($issuer);
					}
				}else{
					$sender = $issuer->username;
				}
				// Ensure params is properly handled as an array
				$paramsArray = is_array($params) ? $params : array();
				$meMessage = "* $sender ".implode(" ", $paramsArray);
				$this->broadcast($meMessage);
				break;
			case "tell":
				if(!isset($params[0]) or !isset($params[1])){
					$output .= "Usage: /$cmd <player> <message>\n";
					break;
				}
				if(!($issuer instanceof Player)){
					$sender = ucfirst($issuer);
				}else{
					$sender = $issuer->username;
				}
				// Most defensive approach - avoid any potential by-reference issues
				$paramsArray = is_array($params) ? $params : array();
				$targetName = "";
				$messageParts = array();
				
				// Safely extract target name and message parts
				if (isset($paramsArray[0])) {
					$targetName = (string)$paramsArray[0];
				}
				
				// Build message from remaining parts
				for ($i = 1; $i < count($paramsArray); $i++) {
					if (isset($paramsArray[$i])) {
						$messageParts[] = (string)$paramsArray[$i];
					}
				}
				
				$target = $this->server->api->player->get($targetName);
				if ($target instanceof Player) {
					$target = $target->username;
				} else {
					$target = strtolower($targetName);
					if ($target === "server" || $target === "console" || $target === "rcon") {
						$target = "Console";
					}
				}
				
				$mes = implode(" ", $messageParts);
				$output .= "[me -> ".$target."] ".$mes."\n";
				if ($target !== "Console" && $target !== "Rcon") {
					$tellMessage = "[".$sender." -> me] ".$mes;
					$this->sendTo(false, $tellMessage, $target);
				}
				console("[INFO] [".$sender." -> ".$target."] ".$mes);
				break;
		}
		return $output;
	}
	
	public function broadcast($message){
		$this->send(false, $message);
	}
	
	public function sendTo($owner, $text, $player){
		// Ensure player is passed as a value, not reference
		$playerArray = array($player);
		$this->send($owner, $text, $playerArray);
	}
	
	public function send($owner, $text, $whitelist = false, $blacklist = false){
		$message = array(
			"player" => $owner,
			"message" => $text,
		);
		if($owner !== false){
			if($owner instanceof Player){
				if($whitelist === false){
					console("[INFO] <".$owner->username."> ".$text);
				}
			}else{
				if($whitelist === false){
					console("[INFO] <".$owner."> ".$text);
				}
			}
		}else{
			if($whitelist === false){
				console("[INFO] $text");
			}
			$message["player"] = "";
		}

		// Ensure all parameters are passed as values, not references
		$messageValue = $message;
		$whitelistValue = $whitelist;
		$blacklistValue = $blacklist;
		$container = new Container($messageValue, $whitelistValue, $blacklistValue);
		$this->server->handle("server.chat", $container);
	}
}
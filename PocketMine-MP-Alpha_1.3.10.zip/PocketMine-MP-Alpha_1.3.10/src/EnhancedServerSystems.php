<?php

/**
 * Enhanced Server Systems for PocketMine-MP Alpha 1.3.10
 * 
 * Main initialization file for all enhanced systems:
 * - Anti-cheat system
 * - Security manager
 * - Player identification system
 * - Mob spawning system
 * - Mob AI system
 * - Inventory persistence fix
 * 
 * @author AxoGM
 */

class EnhancedServerSystems {
    private $server;
    private $antiCheat;
    private $securityManager;
    private $playerIdSystem;
    private $mobSpawning;
    private $mobAI;
    private $inventoryFix;
    
    public function __construct() {
        $this->server = ServerAPI::request();
        $this->initializeSystems();
    }
    
    /**
     * Initialize all enhanced systems
     */
    private function initializeSystems() {
        console("[ENHANCED] Initializing enhanced server systems...");
        
        try {
            // Initialize security systems first
            $this->securityManager = new SecurityManager();
            $this->antiCheat = new AntiCheat();
            
            // Initialize player systems
            $this->playerIdSystem = new PlayerIdentificationSystem();
            $this->inventoryFix = new InventoryPersistenceFix();
            
            // Initialize mob systems (AI first, then spawning with AI reference)
            $this->mobAI = new MobAI();
            $this->mobSpawning = new MobSpawningSystem($this->mobAI);
            
            // Connect the systems
            $this->mobSpawning->setMobAI($this->mobAI);
            
            // Register console commands
            $this->registerCommands();
            
            // Schedule system maintenance
            $this->server->schedule(20 * 300, array($this, "performMaintenance"), array(), true); // Every 5 minutes
            
            console("[ENHANCED] All enhanced systems initialized successfully");
            
        } catch (Exception $e) {
            console("[ENHANCED] Error initializing systems: " . $e->getMessage());
        }
    }
    
    /**
     * Register console commands for the enhanced systems
     */
    private function registerCommands() {
        if (!($this->server->api->console instanceof ConsoleAPI)) {
            return;
        }
        
        // Anti-cheat commands
        $this->server->api->console->register("anticheat", "<status|reset> [player]", array($this, "handleAntiCheatCommand"));
        
        // Security commands
        $this->server->api->console->register("security", "<stats|banip|unbanip> [ip] [reason]", array($this, "handleSecurityCommand"));
        
        // Player ID commands
        $this->server->api->console->register("playerid", "<stats|lookup|cleanup> [player/ip]", array($this, "handlePlayerIdCommand"));
        
        // Mob commands
        $this->server->api->console->register("mobs", "<stats|spawn|clear> [type] [x] [y] [z]", array($this, "handleMobCommand"));
        
        // Inventory commands
        $this->server->api->console->register("inventory", "<save|repair|stats> [player]", array($this, "handleInventoryCommand"));
        
        console("[ENHANCED] Console commands registered");
    }
    
    /**
     * Handle anti-cheat console commands
     */
    public function handleAntiCheatCommand($cmd, $params, $issuer, $alias) {
        $output = "";
        
        if (!isset($params[0])) {
            return "Usage: /anticheat <status|reset> [player]\n";
        }
        
        switch (strtolower($params[0])) {
            case "status":
                if (isset($params[1])) {
                    $player = $this->server->api->player->get($params[1]);
                    if ($player instanceof Player) {
                        $violations = $this->antiCheat->getViolationCount($player);
                        $output .= "Player " . $player->username . " has " . $violations . " violations\n";
                    } else {
                        $output .= "Player not found\n";
                    }
                } else {
                    $output .= "Anti-cheat system is active\n";
                }
                break;
                
            case "reset":
                if (isset($params[1])) {
                    $player = $this->server->api->player->get($params[1]);
                    if ($player instanceof Player) {
                        $this->antiCheat->resetViolations($player);
                        $output .= "Reset violations for " . $player->username . "\n";
                    } else {
                        $output .= "Player not found\n";
                    }
                } else {
                    $output .= "Please specify a player\n";
                }
                break;
                
            default:
                $output .= "Usage: /anticheat <status|reset> [player]\n";
        }
        
        return $output;
    }
    
    /**
     * Handle security console commands
     */
    public function handleSecurityCommand($cmd, $params, $issuer, $alias) {
        $output = "";
        
        if (!isset($params[0])) {
            return "Usage: /security <stats|banip|unbanip> [ip] [reason]\n";
        }
        
        switch (strtolower($params[0])) {
            case "stats":
                $stats = $this->securityManager->getSecurityStats();
                $output .= "Security Statistics:\n";
                $output .= "- Banned IPs: " . $stats['banned_ips'] . "\n";
                $output .= "- Active connections: " . $stats['active_connections'] . "\n";
                $output .= "- Suspicious IPs: " . $stats['suspicious_ips'] . "\n";
                break;
                
            case "banip":
                if (isset($params[1])) {
                    $ip = $params[1];
                    $reason = isset($params[2]) ? implode(" ", array_slice($params, 2)) : "Manual ban";
                    $this->securityManager->banIP($ip, $reason);
                    $output .= "Banned IP: " . $ip . "\n";
                } else {
                    $output .= "Usage: /security banip <ip> [reason]\n";
                }
                break;
                
            case "unbanip":
                if (isset($params[1])) {
                    $ip = $params[1];
                    $this->securityManager->unbanIP($ip);
                    $output .= "Unbanned IP: " . $ip . "\n";
                } else {
                    $output .= "Usage: /security unbanip <ip>\n";
                }
                break;
                
            default:
                $output .= "Usage: /security <stats|banip|unbanip> [ip] [reason]\n";
        }
        
        return $output;
    }
    
    /**
     * Handle player ID console commands
     */
    public function handlePlayerIdCommand($cmd, $params, $issuer, $alias) {
        $output = "";
        
        if (!isset($params[0])) {
            return "Usage: /playerid <stats|lookup|cleanup> [player/ip]\n";
        }
        
        switch (strtolower($params[0])) {
            case "stats":
                $stats = $this->playerIdSystem->getStats();
                $output .= "Player ID Statistics:\n";
                $output .= "- Total players: " . $stats['total_players'] . "\n";
                $output .= "- Online players: " . $stats['online_players'] . "\n";
                $output .= "- IP mappings: " . $stats['ip_mappings'] . "\n";
                $output .= "- Username mappings: " . $stats['username_mappings'] . "\n";
                break;
                
            case "lookup":
                if (isset($params[1])) {
                    $query = $params[1];
                    
                    // Try as IP first
                    $uid = $this->playerIdSystem->getUIDByIP($query);
                    if ($uid !== null) {
                        $output .= "IP " . $query . " belongs to UID: " . $uid . "\n";
                    } else {
                        // Try as username
                        $uid = $this->playerIdSystem->getUIDByUsername($query);
                        if ($uid !== null) {
                            $output .= "Username " . $query . " belongs to UID: " . $uid . "\n";
                        } else {
                            $output .= "No UID found for: " . $query . "\n";
                        }
                    }
                } else {
                    $output .= "Usage: /playerid lookup <player/ip>\n";
                }
                break;
                
            case "cleanup":
                $cleaned = $this->playerIdSystem->cleanupOldMappings();
                $output .= "Cleaned up " . $cleaned . " old player mappings\n";
                break;
                
            default:
                $output .= "Usage: /playerid <stats|lookup|cleanup> [player/ip]\n";
        }
        
        return $output;
    }
    
    /**
     * Handle mob console commands
     */
    public function handleMobCommand($cmd, $params, $issuer, $alias) {
        $output = "";
        
        if (!isset($params[0])) {
            return "Usage: /mobs <stats|spawn|clear> [type] [x] [y] [z]\n";
        }
        
        switch (strtolower($params[0])) {
            case "stats":
                $spawnStats = $this->mobSpawning->getSpawnStats();
                $aiStats = $this->mobAI->getAIStats();
                
                $output .= "Mob Statistics:\n";
                $output .= "- Total mobs: " . $spawnStats['total_mobs'] . "\n";
                $output .= "- Mob types:\n";
                foreach ($spawnStats['mob_types'] as $type => $count) {
                    $output .= "  - " . $type . ": " . $count . "\n";
                }
                $output .= "- AI States:\n";
                foreach ($aiStats['states'] as $state => $count) {
                    $output .= "  - " . ucfirst($state) . ": " . $count . "\n";
                }
                break;
                
            case "spawn":
                if (!($issuer instanceof Player)) {
                    $output .= "This command can only be used in-game\n";
                    break;
                }
                
                if (isset($params[1])) {
                    $mobTypes = array(
                        'zombie' => MOB_ZOMBIE,
                        'skeleton' => MOB_SKELETON,
                        'creeper' => MOB_CREEPER,
                        'spider' => MOB_SPIDER,
                        'pig' => MOB_PIG,
                        'cow' => MOB_COW,
                        'sheep' => MOB_SHEEP,
                        'chicken' => MOB_CHICKEN
                    );
                    
                    $mobType = strtolower($params[1]);
                    if (isset($mobTypes[$mobType])) {
                        $pos = array(
                            'x' => isset($params[2]) ? floatval($params[2]) : $issuer->entity->x,
                            'y' => isset($params[3]) ? floatval($params[3]) : $issuer->entity->y,
                            'z' => isset($params[4]) ? floatval($params[4]) : $issuer->entity->z
                        );
                        
                        if ($this->mobSpawning->forceSpawnMob($mobTypes[$mobType], $pos, $issuer->level)) {
                            $output .= "Spawned " . $mobType . " at (" . $pos['x'] . ", " . $pos['y'] . ", " . $pos['z'] . ")\n";
                        } else {
                            $output .= "Failed to spawn mob (server limit reached?)\n";
                        }
                    } else {
                        $output .= "Invalid mob type. Available: " . implode(", ", array_keys($mobTypes)) . "\n";
                    }
                } else {
                    $output .= "Usage: /mobs spawn <type> [x] [y] [z]\n";
                }
                break;
                
            case "debug":
                if (!($issuer instanceof Player)) {
                    $output .= "This command can only be used in-game\n";
                    break;
                }
                
                $playerPos = array(
                    'x' => $issuer->entity->x,
                    'y' => $issuer->entity->y,
                    'z' => $issuer->entity->z
                );
                
                $output .= "=== MOB DEBUG INFO ===\n";
                $output .= "Player position: (" . round($playerPos['x'], 1) . ", " . round($playerPos['y'], 1) . ", " . round($playerPos['z'], 1) . ")\n";
                
                // Get all entities in the level
                $allEntities = $this->server->api->entity->getAll($issuer->level);
                $mobCount = 0;
                $nearbyMobs = array();
                
                foreach ($allEntities as $entity) {
                    if ($entity->class === ENTITY_MOB) {
                        $mobCount++;
                        $distance = sqrt(
                            pow($entity->x - $playerPos['x'], 2) +
                            pow($entity->y - $playerPos['y'], 2) +
                            pow($entity->z - $playerPos['z'], 2)
                        );
                        
                        if ($distance <= 50) { // Within 50 blocks
                            $mobName = $this->getMobTypeName($entity->type);
                            $nearbyMobs[] = $mobName . " (EID: " . $entity->eid . ", Distance: " . round($distance, 1) . ")";
                        }
                    }
                }
                
                $output .= "Total mobs in level: " . $mobCount . "\n";
                $output .= "Nearby mobs (within 50 blocks):\n";
                if (empty($nearbyMobs)) {
                    $output .= "  None found\n";
                } else {
                    foreach ($nearbyMobs as $mobInfo) {
                        $output .= "  " . $mobInfo . "\n";
                    }
                }
                
                // Get spawn stats
                $spawnStats = $this->mobSpawning->getSpawnStats();
                $output .= "Spawn system tracking: " . $spawnStats['total_mobs'] . " mobs\n";
                break;
                
            case "clear":
                $removed = $this->mobSpawning->removeAllMobs();
                $output .= "Removed " . $removed . " mobs\n";
                break;
                
            case "test":
                if (!($issuer instanceof Player)) {
                    $output .= "This command can only be used in-game\n";
                    break;
                }
                
                // Test mob spawning right next to player
                $pos = array(
                    'x' => $issuer->entity->x + 2,
                    'y' => $issuer->entity->y,
                    'z' => $issuer->entity->z + 2
                );
                
                if ($this->mobSpawning->forceSpawnMob(MOB_PIG, $pos, $issuer->level)) {
                    $output .= "Test pig spawned at your location\n";
                    
                    // Give player some test items
                    if (class_exists('BlockAPI')) {
                        $issuer->addItem(BlockAPI::getItem(STONE, 0, 64));
                        $issuer->addItem(BlockAPI::getItem(WOOD, 0, 32));
                        $issuer->addItem(BlockAPI::getItem(COOKED_PORKCHOP, 0, 16));
                        $output .= "Added test items to inventory\n";
                    }
                } else {
                    $output .= "Failed to spawn test mob\n";
                }
                break;
                
            case "wake":
                if (!($issuer instanceof Player)) {
                    $output .= "This command can only be used in-game\n";
                    break;
                }
                
                // Force all nearby mobs to start wandering
                $wokenMobs = $this->mobAI->wakeUpNearbyMobs($issuer);
                $output .= "Woke up " . $wokenMobs . " mobs - they should start moving now!\n";
                $output .= "Movement is now smoother and more vanilla-like:\n";
                $output .= "- Mobs move 1 block at a time every 1-2 seconds\n";
                $output .= "- Less frequent state changes reduce lag\n";
                $output .= "- Natural wandering patterns\n";
                break;
                
            case "move":
                if (!($issuer instanceof Player)) {
                    $output .= "This command can only be used in-game\n";
                    break;
                }
                
                // Get AI stats to show current mob states
                $aiStats = $this->mobAI->getAIStats();
                $output .= "=== MOB MOVEMENT STATUS ===\n";
                $output .= "Total mobs with AI: " . $aiStats['total_mobs'] . "\n";
                $output .= "Idle: " . $aiStats['states']['idle'] . "\n";
                $output .= "Wandering: " . $aiStats['states']['wandering'] . "\n";
                $output .= "Targeting: " . $aiStats['states']['targeting'] . "\n";
                $output .= "Attacking: " . $aiStats['states']['attacking'] . "\n";
                $output .= "Fleeing: " . $aiStats['states']['fleeing'] . "\n";
                $output .= "\nUse '/mobs wake' to make idle mobs start moving!\n";
                break;
                
            default:
                $output .= "Available commands:\n";
                $output .= "  /mobs stats - Show mob statistics\n";
                $output .= "  /mobs spawn <type> [x] [y] [z] - Spawn a mob\n";
                $output .= "  /mobs debug - Show debug information\n";
                $output .= "  /mobs test - Spawn test mob and give items\n";
                $output .= "  /mobs wake - Wake up nearby mobs (force them to move)\n";
                $output .= "  /mobs move - Show movement status and AI states\n";
                $output .= "  /mobs clear - Remove all mobs\n";
        }
        
        return $output;
    }
    
    /**
     * Handle inventory console commands
     */
    public function handleInventoryCommand($cmd, $params, $issuer, $alias) {
        $output = "";
        
        if (!isset($params[0])) {
            return "Usage: /inventory <save|repair|stats> [player]\n";
        }
        
        switch (strtolower($params[0])) {
            case "save":
                if (isset($params[1])) {
                    $player = $this->server->api->player->get($params[1]);
                    if ($player instanceof Player) {
                        $this->inventoryFix->savePlayerInventory($player);
                        $output .= "Saved inventory for " . $player->username . "\n";
                    } else {
                        $output .= "Player not found\n";
                    }
                } else {
                    $this->inventoryFix->saveAllInventories();
                    $output .= "Saved all player inventories\n";
                }
                break;
                
            case "repair":
                if (isset($params[1])) {
                    $player = $this->server->api->player->get($params[1]);
                    if ($player instanceof Player) {
                        $repaired = $this->inventoryFix->validateAndRepairInventory($player);
                        $output .= $repaired ? "Repaired inventory for " . $player->username . "\n" : "Inventory was already valid\n";
                    } else {
                        $output .= "Player not found\n";
                    }
                } else {
                    $output .= "Usage: /inventory repair <player>\n";
                }
                break;
                
            case "stats":
                $stats = $this->inventoryFix->getInventoryStats();
                $output .= "Inventory Statistics:\n";
                $output .= "- Backups created: " . $stats['backups_created'] . "\n";
                $output .= "- Players with backups: " . implode(", ", $stats['players_with_backups']) . "\n";
                break;
                
            default:
                $output .= "Usage: /inventory <save|repair|stats> [player]\n";
        }
        
        return $output;
    }
    
    /**
     * Perform periodic maintenance on all systems
     */
    public function performMaintenance() {
        try {
            // Clean up old security data
            $this->securityManager->cleanupConnections();
            
            // Clean up old inventory backups
            $this->inventoryFix->cleanupOldBackups();
            
            console("[ENHANCED] Performed system maintenance");
            
        } catch (Exception $e) {
            console("[ENHANCED] Error during maintenance: " . $e->getMessage());
        }
    }
    
    /**
     * Get overall system status
     */
    public function getSystemStatus() {
        return array(
            'anticheat' => $this->antiCheat !== null,
            'security' => $this->securityManager !== null,
            'player_id' => $this->playerIdSystem !== null,
            'mob_spawning' => $this->mobSpawning !== null,
            'mob_ai' => $this->mobAI !== null,
            'inventory_fix' => $this->inventoryFix !== null
        );
    }
    
    /**
     * Get mob type name from mob type ID
     */
    private function getMobTypeName($mobType) {
        $mobNames = array(
            MOB_ZOMBIE => "Zombie",
            MOB_SKELETON => "Skeleton",
            MOB_CREEPER => "Creeper",
            MOB_SPIDER => "Spider",
            MOB_PIG => "Pig",
            MOB_COW => "Cow",
            MOB_SHEEP => "Sheep",
            MOB_CHICKEN => "Chicken"
        );
        
        return isset($mobNames[$mobType]) ? $mobNames[$mobType] : "Unknown(" . $mobType . ")";
    }
    
    /**
     * Shutdown all systems gracefully
     */
    public function shutdown() {
        console("[ENHANCED] Shutting down enhanced systems...");
        
        try {
            // Save all inventories before shutdown
            if ($this->inventoryFix !== null) {
                $this->inventoryFix->saveAllInventories();
            }
            
            // Clean up mob spawning
            if ($this->mobSpawning !== null) {
                $this->mobSpawning->removeAllMobs();
            }
            
            console("[ENHANCED] Enhanced systems shut down successfully");
            
        } catch (Exception $e) {
            console("[ENHANCED] Error during shutdown: " . $e->getMessage());
        }
    }
}
# Enhanced PocketMine-MP Alpha 1.3.10 Features

This document describes all the enhanced features and improvements added to the PocketMine-MP Alpha 1.3.10 server.

## Overview

The enhanced server includes the following major improvements:

1. **Security Hardening and Anti-Cheat System**
2. **Player Identification System**
3. **Vanilla Mob Spawning System**
4. **Basic Mob AI System**
5. **Inventory Persistence Fix**
6. **PHP Code Modernization**

## 1. Security Hardening and Anti-Cheat System

### Anti-Cheat Features

The anti-cheat system provides server-side validation to detect and prevent common cheating methods:

- **Fly/Noclip Detection**: Detects players moving vertically or through blocks in ways not possible in survival mode
- **Speed Hack Detection**: Monitors player movement speed and flags excessive speeds
- **Impossible Reach Detection**: Validates the distance between players and blocks/entities they interact with
- **Automatic Response**: Warns players, teleports them back, or kicks repeat offenders

#### Configuration Constants
- `MAX_SPEED_SURVIVAL`: 7.0 blocks per second
- `MAX_SPEED_CREATIVE`: 15.0 blocks per second
- `MAX_REACH_DISTANCE`: 6.0 blocks
- `VIOLATION_THRESHOLD`: 5 violations before kick

#### Console Commands
- `/anticheat status [player]` - Check violation count for a player
- `/anticheat reset <player>` - Reset violations for a player

### Security Manager Features

The security manager provides comprehensive server protection:

- **Connection Rate Limiting**: Prevents connection spam from single IPs
- **Brute Force Protection**: Blocks IPs after multiple failed login attempts
- **Input Sanitization**: Prevents injection attacks through command input
- **Dangerous Command Filtering**: Blocks potentially harmful commands
- **IP Banning System**: Enhanced IP ban management with reasons and timestamps

#### Configuration Constants
- `MAX_CONNECTIONS_PER_IP`: 3 simultaneous connections
- `CONNECTION_TIMEOUT`: 300 seconds (5 minutes)
- `MAX_LOGIN_ATTEMPTS`: 5 attempts before blocking
- `BRUTE_FORCE_TIMEOUT`: 1800 seconds (30 minutes)

#### Console Commands
- `/security stats` - View security statistics
- `/security banip <ip> [reason]` - Ban an IP address
- `/security unbanip <ip>` - Unban an IP address

## 2. Player Identification System

### Unique Player IDs

The player identification system ensures each player has a unique identity:

- **Unique ID Generation**: Creates random alphanumeric IDs for new players
- **Name Disambiguation**: Automatically resolves username conflicts by appending numbers
- **IP Tracking**: Associates player IDs with IP addresses for recognition
- **Persistent Data**: Player data is stored using UIDs instead of usernames

#### Features
- Automatic username conflict resolution (e.g., "Steve" becomes "Steve1" if "Steve" is online)
- Cross-session player recognition even with IP changes
- Persistent player data tied to unique IDs
- Protection against username impersonation

#### Console Commands
- `/playerid stats` - View player ID system statistics
- `/playerid lookup <player/ip>` - Look up UID by player name or IP
- `/playerid cleanup` - Clean up old player mappings

## 3. Vanilla Mob Spawning System

### Dynamic Mob Spawning

The mob spawning system mimics vanilla Minecraft behavior:

- **Time-Based Spawning**: Hostile mobs spawn at night, passive mobs during day
- **Location-Based Spawning**: Mobs spawn in random locations around players
- **Spawn Limits**: Configurable limits prevent server lag
- **Proper Distribution**: Weighted spawning for different mob types

#### Configuration Constants
- `SPAWN_INTERVAL`: 600 ticks (10 minutes) between spawn attempts
- `MIN_SPAWN_RADIUS`: 24 blocks minimum distance from players
- `MAX_SPAWN_RADIUS`: 128 blocks maximum distance from players
- `MAX_MOBS_PER_PLAYER`: 8 mobs maximum around each player
- `MAX_TOTAL_MOBS`: 50 total mobs on server

#### Supported Mobs
**Hostile (Night):**
- Zombies
- Skeletons
- Creepers
- Spiders

**Passive (Day):**
- Pigs
- Cows
- Sheep
- Chickens

#### Console Commands
- `/mobs stats` - View mob spawning statistics
- `/mobs spawn <type> [x] [y] [z]` - Force spawn a mob
- `/mobs clear` - Remove all spawned mobs

## 4. Basic Mob AI System

### Intelligent Mob Behavior

The AI system provides realistic mob behaviors:

#### Hostile Mob AI
- **Target Detection**: Mobs detect nearby players within sight range
- **Pathfinding**: Mobs move towards targeted players
- **Attack Behavior**: Melee attacks when in range
- **Line of Sight**: Basic visibility checks

#### Passive Mob AI
- **Wandering**: Random movement when idle
- **Flee Behavior**: Run away when damaged by players
- **Natural Behavior**: Realistic animal-like movement patterns

#### AI States
- `IDLE`: Mob is stationary
- `WANDERING`: Mob is moving randomly
- `TARGETING`: Hostile mob is pursuing a player
- `ATTACKING`: Hostile mob is attacking a player
- `FLEEING`: Passive mob is running from a threat

#### Configuration Constants
- `SIGHT_RANGE`: 16.0 blocks detection range
- `ATTACK_RANGE`: 2.0 blocks attack range
- `FLEE_RANGE`: 8.0 blocks flee distance
- `AI_UPDATE_INTERVAL`: 10 ticks (0.5 seconds) between AI updates

## 5. Inventory Persistence Fix

### Reliable Inventory Saving

The inventory persistence fix ensures player inventories are properly saved and loaded:

- **Enhanced Save Logic**: Improved inventory serialization
- **Load Validation**: Validates inventory data on player join
- **Backup System**: Creates inventory backups for recovery
- **Error Handling**: Graceful handling of corrupted data
- **Periodic Saves**: Regular inventory saves as backup

#### Features
- Automatic inventory backup creation
- Data validation and repair
- Recovery from corrupted inventory data
- Enhanced error logging
- Periodic save system

#### Console Commands
- `/inventory save [player]` - Save inventory for player or all players
- `/inventory repair <player>` - Validate and repair player inventory
- `/inventory stats` - View inventory system statistics

## 6. PHP Code Modernization

### Compatibility Improvements

The codebase has been modernized while maintaining PHP 5.x compatibility:

- **Compatibility Layer**: Provides modern PHP functions for older versions
- **Enhanced Error Handling**: Better exception handling and logging
- **Code Standards**: Improved code structure and documentation
- **Performance Optimizations**: More efficient algorithms and data structures

#### Compatibility Functions Added
- `str_starts_with()` and `str_ends_with()` for PHP < 8.0
- `str_contains()` for PHP < 8.0
- `array_key_first()` and `array_key_last()` for PHP < 7.3
- Enhanced JSON handling with error checking
- Modern string and file utilities

## Installation and Configuration

### Automatic Installation

The enhanced systems are automatically loaded when the server starts. No additional configuration is required for basic functionality.

### File Structure

```
src/
├── security/
│   ├── SecurityManager.php      # Security and connection management
│   └── AntiCheat.php           # Anti-cheat detection system
├── player/
│   ├── PlayerIdentificationSystem.php  # Unique player IDs
│   └── InventoryPersistenceFix.php     # Inventory save/load fixes
├── world/
│   └── MobSpawningSystem.php    # Mob spawning logic
├── entity/
│   └── MobAI.php               # Mob artificial intelligence
├── utils/
│   └── PHPCompatibility.php    # PHP compatibility layer
└── EnhancedServerSystems.php   # Main system coordinator
```

### Data Files

The enhanced systems create the following data files:

- `data/ip_to_uid_map.json` - IP to UID mappings
- `data/username_to_uid_map.json` - Username to UID mappings
- `data/players/[UID].yml` - Player data files (using UIDs)
- `data/banned-ips.txt` - Enhanced IP ban list

## Performance Considerations

### Resource Usage

The enhanced systems are designed to be lightweight:

- **Minimal Memory Usage**: Efficient data structures and cleanup routines
- **CPU Optimization**: Configurable update intervals to balance performance
- **Network Efficiency**: Reduced packet overhead through smart updates
- **Storage Optimization**: Compressed data storage and periodic cleanup

### Recommended Settings

For optimal performance on different server sizes:

**Small Server (1-10 players):**
- Default settings work well
- Consider reducing mob limits if needed

**Medium Server (10-30 players):**
- Increase `MAX_TOTAL_MOBS` to 100
- Reduce `AI_UPDATE_INTERVAL` to 15 ticks

**Large Server (30+ players):**
- Increase `MAX_TOTAL_MOBS` to 200
- Increase `SPAWN_INTERVAL` to 1200 ticks
- Consider disabling some AI features if needed

## Troubleshooting

### Common Issues

**High CPU Usage:**
- Increase AI update intervals
- Reduce maximum mob counts
- Check for excessive mob spawning

**Memory Issues:**
- Enable periodic cleanup
- Reduce player data retention time
- Monitor inventory backup creation

**Network Lag:**
- Reduce mob update frequency
- Limit simultaneous connections per IP
- Check for connection spam

### Debug Commands

Use these commands to diagnose issues:

```
/anticheat status          # Check anti-cheat violations
/security stats           # View security statistics
/playerid stats          # Check player ID system
/mobs stats              # Monitor mob spawning
/inventory stats         # Check inventory system
```

### Log Files

Monitor these log entries for issues:

- `[SECURITY]` - Security-related events
- `[ANTICHEAT]` - Anti-cheat violations
- `[PLAYER-ID]` - Player identification events
- `[MOB-SPAWN]` - Mob spawning activities
- `[MOB-AI]` - AI behavior events
- `[INVENTORY-FIX]` - Inventory operations
- `[ENHANCED]` - System status messages

## Compatibility

### PHP Version Support

- **Minimum**: PHP 5.4.0
- **Recommended**: PHP 5.6.0 or higher
- **Tested**: PHP 5.4, 5.5, 5.6, 7.0, 7.1, 7.2

### PocketMine-MP Compatibility

- **Target Version**: Alpha 1.3.10
- **Protocol**: Version 12
- **Minecraft PE**: v0.7.6 alpha

### Extension Requirements

Required PHP extensions:
- `sockets` (recommended)
- `curl` (required)
- `sqlite3` (required)
- `zlib` (required)
- `json` (required)

## Security Considerations

### Best Practices

1. **Regular Monitoring**: Check security logs regularly
2. **Update Bans**: Keep IP ban lists updated
3. **Monitor Performance**: Watch for unusual resource usage
4. **Backup Data**: Regular backups of player data
5. **Network Security**: Use firewalls and DDoS protection

### Security Features

- Input sanitization prevents injection attacks
- Rate limiting prevents connection spam
- Brute force protection blocks repeated attacks
- Command validation prevents dangerous operations
- Enhanced logging for security auditing

## Contributing

### Code Standards

- Follow existing code style
- Add comprehensive comments
- Include error handling
- Test with multiple PHP versions
- Document new features

### Reporting Issues

When reporting issues, include:
- PHP version
- Server configuration
- Error messages
- Steps to reproduce
- Expected vs actual behavior

## License

This enhanced version maintains the original LGPL license of PocketMine-MP Alpha 1.3.10.

## Changelog

### Version 1.0.0 (Initial Release)
- Added comprehensive anti-cheat system
- Implemented security hardening
- Created player identification system
- Added vanilla mob spawning
- Implemented basic mob AI
- Fixed inventory persistence issues
- Modernized PHP codebase
- Added extensive documentation

---

For technical support or questions about these enhancements, please refer to the troubleshooting section or check the server logs for detailed error information.